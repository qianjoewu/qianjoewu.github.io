####################################
###                              ###
###        OSM simulation        ###
###                              ###
####################################
# Author: Qian Wu
# Runtime: ~10min

# Simulated FWER under "worst case" / least favorable null
(st <- Sys.time())

# Load files/packages
source("osm.R")
OUTFILE <- "osm_sim.txt"

# J: number of categories of Y
# K: number of categories of X
# (Assuming K>=3, J>=3, otherwise X and/or Y is just binary)
# n: subsample size for each X=x, so total sample size is n*K
# N: number of draws for computing critical value
# NREP: number of simulated datasets in simulation
# alpha: nominal/desired FWER
sims <- function(J, K, n, N, NREP, alpha) {
  # Save/set seeds for replicability
  oldseed <- NULL
  if (exists(".Random.seed",.GlobalEnv)) { #.Random.seed #restore state at end
    oldseed <- get(".Random.seed",.GlobalEnv)
  }
  on.exit(if (!is.null(oldseed)) { assign(".Random.seed", oldseed, .GlobalEnv) }, add=TRUE)
  set.seed(112358) # for replication

  rejs <- array(NA, dim=c(K-1,J-1,NREP)) # to store rejections
  cv <- rep(NA,NREP) # to store critical values
  for (irep in 1:NREP) { # Main simulation loop
    # Simulate data per DGP
    Y <- rep(NA,n*K)
    X <- rep(NA,n*K)
    for (k in 1:K) {
      X[(n*(k-1)+1):(n*k)]<-rep(k,n)
      Y[(n*(k-1)+1):(n*k)]<-sample(1:J, n, replace = TRUE, prob = rep(1/J, J))
    }
    # Run MTP and store results
    test <- osm(Y=Y, X=X, alpha=alpha, N=N)
    rejs[,,irep] <- test$rejections.original.H0
    cv[irep] <- test$cv
  }
  
  single <- apply(simplify2array(rejs), 1:2, mean) # error rate for each single H0_{x,y}
  
  aa <- rep(NA,NREP)
  for (i in 1:NREP) aa[i] <- any(rejs[,,i])
  FWER <- mean(aa) # familywise error rate
  
  result <- list(single, FWER, range(cv))
  names(result) <- list("single H0 error rate", "FWER","cv_value")
  return(result)
}



# Simulations in the paper
NREP <- 1000
JK <- rbind(c(4,4),6:5,c(8,10))
ALPHA <- c(rep(0.05,5),0.1,0.01)
N <- c(rep(1e3,4),rep(1e4,3))
nx <- c(20, 100, 1000, rep(1e4,4))
sink(file=OUTFILE, append=TRUE)
for (i in 1:nrow(JK)) {
  J <- JK[i,1];  K <- JK[i,2]
  for (p in 1:length(nx)) {
    ret <- sims(J=J, K=K, n=nx[p], N=N[p], NREP=NREP, alpha=ALPHA[p])
    cat(sprintf("%2d & %2d & %6d & %6d & %4.2f & %6.4f & %6.4f & %7.5f \\\\%s\n",
                J, K, nx[p], N[p], ALPHA[p],
                ret[['cv_value']][1], ret[['cv_value']][2], unlist(ret[['FWER']]),
                ifelse(p==length(nx) && i<nrow(JK),'[2pt]','')))
  }
}
Sys.time()-st # total elapsed time
sink()
#EOF