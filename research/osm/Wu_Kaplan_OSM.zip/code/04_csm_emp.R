####################################
###                              ###   
###    CSM Empirical examples    ###
###                              ###
####################################
# Authors: Qian Wu & David M. Kaplan

# Example 1: physical component score vs. education
# Example 2: mental component score vs. education

# For saving results
OUTFILE <- "04_csm_emp_output.txt"

# Load files/packages
source("csm.R")
library(ggplot2)
library(scales)

# Settings for csm()
ALPHA <- 0.05 # overall FWER level

# Load data
df <- read.csv(file='selectuk.csv', fileEncoding='UTF-16LE') # created by 01_osm_emp_variable_selection22.R; raw UKHLS 2022 but only selected variables

# Age of the adult
age <- df$lmn_age_dv

# E is educational level, with categories {no HS, HS only, bachelor's, above bachelor's}, coded as 1-4
E <- df$lmn_nisced11_dv
# Note nobody in categories 0,1,4,5:  mean(E %in% c(0,1,4,5)) = 0
E[E==2] <- 21
E[E==3] <- 22
E[E==6] <- 23
E[E>=7 & E<=8] <- 24
E <- E - 20
edu.labels <- c("no-HS","HS","bachelor's","grad deg")

# Physical component score, rescaled to 0-100
PCS <- df$lmn_sf12pcs_dv
PCS <- (PCS - min(PCS[PCS>=0])) / (max(PCS[PCS>=0]) - min(PCS[PCS>=0])) * 100

# Mental component score, rescaled to 0-100
MCS <- df$lmn_sf12mcs_dv
MCS <- (MCS - min(MCS[MCS>=0])) / (max(MCS[MCS>=0]) - min(MCS[MCS>=0])) * 100

# Filter to obs w/ non-missing values and 30<=age<=65  (UK retirement age is 66.8)
tmp <- with(data=df, lmn_age_dv>=30 & lmn_age_dv<=65 & lmn_nisced11_dv>=2 & lmn_nisced11_dv<=8)
keep.inds1 <- tmp & (df$lmn_sf12pcs_dv > -1) # negative values are various types of missing
keep.inds2 <- tmp & (df$lmn_sf12mcs_dv > -1)
if (any(keep.inds1!=keep.inds2)) stop("Unexpected discrepancy: keep.inds1!=keep.inds2")
keep.inds <- keep.inds1  # they're the same, so just use single keep.inds


### Example 1: physical component score vs. education

sink(file=OUTFILE, append=TRUE)
# tilde(Y=PCS[keep.inds], X=E[keep.inds], alpha=ALPHA)
(results <- csm(Y=PCS[keep.inds], X=E[keep.inds], alpha=ALPHA))
sink()

# Plot the "raw" distributions of Y & X
Y <- PCS[keep.inds]
X <- E[keep.inds]
pdf(file='csm_cdf.pdf', width=3.75, height=2.5, pointsize=11)
LWD <- 2
cols <- RColorBrewer::brewer.pal(n=9, name='BuGn')[c(4,5,7:9)]
par(family="sans", mar=c(3.1, 2.9, 0.9, 0.8), mgp=c(2,0.8,0),
    cex.axis=0.85, cex.lab=0.9) #lend=1
plot(ecdf(Y[X==1]), pch=NA, lty=1, verticals=T, col=cols[1],
     xlim=c(0,100), ylim=0:1, xaxs='i', yaxs='i', lwd=LWD,
     xlab='Physical component score', ylab='Empirical CDF', main='', axes=FALSE)
for (x in 2:4) plot(ecdf(Y[X==x]), pch=NA, lty=1, verticals=T, col=cols[x], lwd=LWD, add=TRUE)
box()
axis(side=1, at=seq(0, 100, by=20), labels=seq(0, 100, by=20))
axis(side=2, at=0:4/4, labels=sprintf('%4.2f',0:4/4))
legend('topleft', legend=c('no-HS','HS',"bachelor's",'grad deg'),
       col=cols, lty=1, lwd=LWD, bg='white', cex=0.85)
dev.off()

# Plot inner and outer confidence sets
pdf(file='csm_emp.pdf', width=3.75, height=2.5, pointsize=11)
ggplot() +
  geom_rect(data = results[["outer CS"]], 
            aes(xmin = group - 0.3,  xmax = group + 0.3,
                ymin = from, ymax = to), 
            fill = "gray", color = NA, alpha = 0.1) +
  geom_rect(data = results[["inner CS"]], 
            aes(xmin = group - 0.3, xmax = group + 0.3,
                ymin = from, ymax = to), 
            fill = "black", color = NA, alpha = 0.3) +
  scale_y_continuous(
    limits = c(0, 100),
    breaks = seq(0, 100, by = 20),
    labels = seq(0, 100, by = 20),
    expand = c(0, 0)
  ) +
  scale_x_continuous(
    labels = c("1 (vs. 2)", "2 (vs. 3)", "3 (vs. 4)"),
    breaks = 1:3,
    name = "Education category"
  ) +
  theme_minimal() +
  labs(y = "Physical component score") +
  theme(
    legend.position = "none",
    axis.text = element_text(size = 8), 
    axis.title = element_text(size = 9),
    plot.margin = margin(t = 5, r = -10, b = 1, l = 1),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank()
  )
dev.off()



### Example 2: mental component score vs. education

sink(file=OUTFILE, append=TRUE)
# tilde(Y=MCS[keep.inds], X=E[keep.inds], alpha=ALPHA)
(results2 <- csm(Y=MCS[keep.inds], X=E[keep.inds], alpha=ALPHA))
sink()

# Plot the "raw" distributions of Y & X
Y <- MCS[keep.inds]
X <- E[keep.inds]
pdf(file='csm_cdf_app.pdf', width=4.5, height=3.0, pointsize=11)
LWD <- 2
cols <- RColorBrewer::brewer.pal(n=9, name='BuGn')[c(4,5,7:9)]
par(family="sans", mar=c(3.1, 2.9, 0.9, 0.8), mgp=c(2,0.8,0),
    cex.axis=0.9, cex.lab=0.9) #lend=1
plot(ecdf(Y[X==1]), pch=NA, lty=1, verticals=T, col=cols[1],
     xlim=c(0,100), ylim=0:1, xaxs='i', yaxs='i', lwd=LWD,
     xlab='Mental component score', ylab='Empirical CDF', main='', axes=FALSE)
for (x in 2:4) plot(ecdf(Y[X==x]), pch=NA, lty=1, verticals=T, col=cols[x], lwd=LWD, add=TRUE)
box()
axis(side=1, at=seq(0, 100, by=20), labels=seq(0, 100, by=20))
axis(side=2, at=0:4/4, labels=sprintf('%4.2f',0:4/4))
legend('topleft', legend=c('no-HS','HS',"bachelor's",'grad deg'),
       col=cols, lty=1, lwd=LWD, bg='white', cex=0.9)
dev.off()

# Plot inner and outer confidence sets
pdf(file='csm_emp_app.pdf', width=4.5, height=3, pointsize=11)
ggplot() +
  geom_rect(data = results2[["outer CS"]], 
            aes(xmin = group - 0.3,  xmax = group + 0.3,
                ymin = from, ymax = to), 
            fill = "gray", color = NA, alpha = 0.1) +
  geom_rect(data = results2[["inner CS"]], 
            aes(xmin = group - 0.3, xmax = group + 0.3,
                ymin = from, ymax = to), 
            fill = "black", color = NA, alpha = 0.3) +
  scale_y_continuous(
    limits = c(0, 100),
    breaks = seq(0, 100, by = 20),
    labels = seq(0, 100, by = 20),
    expand = c(0, 0)
  ) +
  scale_x_continuous(
    labels = c("1 (vs. 2)", "2 (vs. 3)", "3 (vs. 4)"),
    breaks = 1:3,
    name = "Education category"
  ) +
  theme_minimal() +
  labs(y = "Mental component score") +
  theme(
    legend.position = "none",
    axis.text = element_text(size = 9), 
    axis.title = element_text(size = 10),
    plot.margin = margin(t = 5, r = -10, b = 1, l = 1),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank()
  )
dev.off()

#EOF