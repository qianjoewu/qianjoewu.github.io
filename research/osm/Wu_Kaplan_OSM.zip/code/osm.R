####################################
###                              ###
###     OSM Multiple Testing     ###   
###                              ###
####################################
# Author: Qian Wu

# Load files/packages
library(MASS)

# Y: vector with data for ordinal outcome of interest (coded as numeric values)
# X: vector with data for covariate (ordinal, discrete, or discretized continuous)
# Note Y and X must each have at least 3 distinct values
# alpha: desired familywise error rate (FWER)
# N: number of draws for computing critical value (larger=more accurate but slower)
osm <- function(Y, X, alpha, N=1e3) { 
  # Some argument validation
  if (missing(Y) || missing(X) || missing(alpha)) stop("Arguments Y, X, and alpha must be provided")

  # Store/set seed for replicability
  oldseed <- NULL
  if (exists(".Random.seed",.GlobalEnv)) { #.Random.seed #restore state at end
    oldseed <- get(".Random.seed",.GlobalEnv)
  }
  on.exit(if (!is.null(oldseed)) { assign(".Random.seed", oldseed, .GlobalEnv) }, add=TRUE)
  set.seed(112358) # for replication

  # Prep data
  sortX <- sort(unique(X))
  K <- length(unique(X))     # K = number of distinct X values
  sortY <- sort(unique(Y))
  J <- length(unique(Y))     # J = number of distinct Y values
  nx <- table(X)             # length K vector of subsample sizes (for each distinct X value)
  gamma <- nx[1] / nx        # as in paper, gamma[i] = nx[1] / nx[i]
  
  Fhat <- matrix(data=NA, nrow=K, ncol=J-1) # Fhat[k,j] is the estimator of conditional CDF F_x(y) when x=k and y=j
  for (k in 1:K) {
    Yx <- Y[X==sortX[k]]
    for (j in 1:(J-1)) Fhat[k,j] <- mean( Yx <= sortY[j] )
  }
  
  Vhat <- Fhat*(1-Fhat) # Vhat[k,j] is the scaled variance of the conditional CDF evaluated at x=k and y=j
  
  Sigma <- vector("list", K) # Sigma matrices from paper
  for (i in 1:K) {
    Sigma[[i]] <- matrix(data=NA, nrow=J-1, ncol=J-1)
    for (j in 1:(J-1)) {
      for (k in 1:(J-1)) {
        Sigma[[i]][k,j] <- gamma[i]*Fhat[i,min(k,j)]*(1-Fhat[i,max(k,j)])
      }
    }
  }
  
  a <- array(data=NA, dim=c(K-1,K-1,J-1,J-1)) # for building matrix V
  for (n in 1:(J-1)) {
    for (m in 1:(J-1)) {
      a[,,m,n] <- diag(K-1)
      for (i in 1:(K-1)){
        a[,,m,n][i,i] <- Sigma[[K+1-i]][m,n]+Sigma[[K-i]][m,n]
        if (i!=(K-1)) {
          a[,,m,n][i,i+1] <- a[,,m,n][i+1,i] <- -Sigma[[K-i]][m,n]
        }
      }
    }
  }
  
  V <- matrix(data=NA, nrow=(K-1)*(J-1), ncol=(K-1)*(J-1))
  for (n in 1:(J-1)) {
    for (m in 1:(J-1)) {
      V[ ((K-1)*(m-1)+1):((K-1)*m) , ((K-1)*(n-1)+1):((K-1)*n) ] <- a[,,m,n]
    }
  }
  
  lambda <- diag(1/sqrt(diag(V)))
  lambda[!is.finite(lambda)] <- 1/0.00001 # if std err=0 exactly, then replace with 0.00001 (a small number)

  joint_d <- lambda %*% V %*% lambda # est'd covariance of asy joint distribution of t-statistics
  
  # Take N random draws from approximate (asymptotic) multivariate normal distribution of t-statistics under least favorable null
  # only works if joint_d is positive definite: mvnd <- matrix(rnorm((J-1)*(K-1)*N), nrow=N) %*% chol(joint_d)
  mvnd <- mvrnorm(n=N, rep(0, (J-1)*(K-1)), joint_d, tol=1e-6, empirical=FALSE, EISPACK=FALSE)

  Tmax <- apply(X=mvnd, MARGIN=1, FUN=max) # max of each simulated normal vector
  cval <- quantile(Tmax, 1-alpha, type=6)  # critical value
  
  that0 <- matrix(NA, nrow=K-1, ncol=J-1) # actual t-statistics, \hat{t}_{x,y}(0) in paper
  for (k in 1:(K-1)) {
    for (j in 1:(J-1)) {
      that0[k,j] <- (Fhat[k+1,j]-Fhat[k,j])*sqrt(nx[1]) / sqrt(Sigma[[k]][j,j]+Sigma[[k+1]][j,j])
    }
  }
  that0[!is.finite(that0)] <- 0 # for t statistic= 0/0, assign it = 0
  
  rej1 <- (that0 >  cval) # rejections with original hypotheses <=0
  rej2 <- (that0 < -cval) # rejections with opposite hypotheses >=0
  
  result <- list(Fhat, that0, cval, rej1, rej2)
  # names(result) <- list("Fhat_x(y)","that_{x,y}(0) test statistics","simulated critical value","MTP rejections with original hypotheses","MTP rejections with opposite hypoytheses")
  names(result) <- list("F.hat","t.statistics","cv","rejections.original.H0","rejections.reversed.H0")
  
  return(result)
} # end of osm()
#EOF