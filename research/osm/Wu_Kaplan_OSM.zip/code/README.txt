Instructions for replicating simulation and empirical analyses for
"Multiple Testing of Stochastic Monotonicity"
by Qian Wu and David M. Kaplan

Files not mentioned below
  a. osm.R: our code for multiple testing with ordinal Y
  b. csm.R: our code for multiple testing with continuous Y
  c. GK_dist_inf_2s_lookup.txt: stored alpha tilde table, use for
     multiple testing with continuous Y (step 4)
  d. selectuk_codebook.pdf: relevant pages of the codebook
     (variable descriptions) for the Understanding Society 2022 data
     (formerly/also known as UKHLS)


Steps for replication

0. Before you start
 a. Make sure all files are in the same directory.
 b. Make sure the directory with all the files is the working
    directory in R; run getwd() if you're not sure, and change the 
    working directory with setwd(...) if necessary.
 c. Note: all file input and output is from/to the working directory.

1  Optional: to replicate from the raw UKHLS 2022 data that you can 
   download yourself, run 01_osm_emp_variable_selection.R after 
   saving the raw UKHLS 2022 data as lmn_indresp.dta
 a. Goal: select (only) the needed variables from the raw data
 b. Input: lmn_indresp.dta (raw UKHLS 2022 data downloaded from their website)
 c. Output: selectuk.csv (the data file we provide)

2.  Run 02_osm_sim.R
 a. Goal: main simulation results
 b. Input: n/a
 c. Output: 02_osm_sim_output.txt

3.  Run 03_osm_emp.R
 a. Goal: mosaic plots and multiple testing results for two examples
    with ordinal outcomes (general health and life satisfaction)
 b. Input: selectuk.csv
 c. Output: 
   i. osm_emp.pdf: mosaic plot for general health vs education
   ii. osm_emp_app.pdf: mosaic plot for overall life satisfaction vs edu
   iii. 03_osm_emp_output.txt: multiple testing results
 
4.  Run 04_csm_emp.R
 a. Goal: CDF plots and multiple testing results for two examples
    with continuous outcomes (PCS and MCS)
 b. Inputs: selectuk.csv and GK_dist_inf_2s_lookup.txt
 c. Output: 
   i. csm_cdf.pdf: CDF plot for PCS (physical component score)
   ii. csm_emp.pdf: inner and outer CS plots for PCS 
   iii. csm_cdf_app.pdf: CDF plot for MCS (mental component score)
   iv. csm_emp_app.pdf: inner and outer CS plots for MCS
   v. 04_csm_emp_output.txt: multiple testing results
