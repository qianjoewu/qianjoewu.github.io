#################################################
###                                           ###
###   SM Multiple Testing with continuous Y   ###   
###                                           ###
#################################################
# Authors: Qian Wu & David M. Kaplan

# Load files/packages
prob.loaded <- exists("GK.dist.inf")
success <-
  tryCatch({source('https://raw.githubusercontent.com/kaplandm/R/main/GK_dist_inf.R');TRUE},
           error=function(w) FALSE)
if (!success) {
  success <-
    tryCatch({source("GK_dist_inf.R");TRUE},
             error=function(w) FALSE)
  if (!success) {
    if (prob.loaded) {
      warning("Couldn't load GK_dist_inf.R, but it seems like you already did.")
    } else {
      stop("Failed to source() GK_dist_inf.R from web or local file.  You may download and source() it yourself, or at least make sure it's in your getwd().  Currently available at https://github.com/kaplandm/R")
    }
  }
}

# This code includes two functions:
# The first function [tilde] simulates alpha tilde using the sample data and stores the results in GK_dist_inf_2s_lookup.txt, which will be used by the second function. Note that this process is time-consuming, so we highly recommend running the two functions separately.
# The second function [csm] returns the SM multiple testing results, including inner and outer confidence sets and graphs.

# Y: vector with data for continuous outcome of interest (coded as numeric values)
# X: vector with data for covariate (ordinal, discrete, or discretized continuous)  (X must have at least 3 distinct values)
#    assumed to take values in 1:K for some K; that is, sort(unique(X)) = 1:K
# alpha: desired familywise error rate (FWER)


tilde <- function(Y, X, alpha) {
  # Bonferroni-adjusted FWER level for each pairwise test
  K <- length(unique(X))  
  alpha_pairwise <- alpha/(K-1)  # K-1 comparisons: 1v2, 2v3, ..., (K-1) vs. K
  # Simulate alpha tildes to store in GK_dist_inf_2s_lookup.txt
  for (i in 1:(K-1)) {
    GK.dist.inf.2s.calibrate(NS=rbind(sum(X==(i+1)),sum(X==i)),
                             ALPHAS=alpha_pairwise*2) # adjust *2 for one-sided use later
  }
}


csm <- function(Y, X, alpha) {
  # Bonferroni-adjusted FWER level for each pairwise test
  K <- length(unique(X))  # number of X categories
  alpha_pairwise <- alpha/(K-1)

  outerCS <- innerCS <- NULL
  for (i in 1:(K-1)) {
    Y_curr <- Y[X==(i+1)]
    Y_prev <- Y[X==i]

    tmp <- GK.dist.inf(X=Y_curr, Y=Y_prev, alpha=alpha_pairwise, ONESIDED = +1, PLOT.FLAG=FALSE)
    tmp_oppo <- GK.dist.inf(X=Y_prev, Y=Y_curr, alpha=alpha_pairwise, ONESIDED = +1, PLOT.FLAG=FALSE)
    
    rej <- GK.dist.inf.rej.2s.r(tmp)
    rej.out <- subset(rej, reject == FALSE)
    outerCS <- rbind(outerCS, data.frame(group=i, from=rej.out$from, to=rej.out$to))

    rej_oppo <- GK.dist.inf.rej.2s.r(tmp_oppo)
    rej.in <- subset(rej_oppo, reject == TRUE)
    if (nrow(rej.in)>0) {
      innerCS <- rbind(innerCS, data.frame(group=i, from=rej.in$from, to=rej.in$to))
    }
  }

  result <- list(innerCS, outerCS)
  names(result) <- list("inner CS","outer CS")
  return(result)
} # end of csm()

#EOF