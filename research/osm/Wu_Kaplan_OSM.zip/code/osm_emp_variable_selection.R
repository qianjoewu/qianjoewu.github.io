# Select variables from full NHIS 2019
df <- read.csv(file='adult19.csv', fileEncoding="UTF-8-BOM")
varnames <- c('AGEP_A','EDUC_A','PHQCAT_A','PHSTAT_A')
write.csv(x=df[,varnames], file='osm_emp.csv', fileEncoding='UTF-16LE', row.names=FALSE)
