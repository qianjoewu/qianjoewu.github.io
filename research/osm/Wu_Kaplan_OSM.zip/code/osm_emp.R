####################################
###                              ###   
###     Empirical examples       ###
###                              ###
####################################
# Author: Qian Wu

# Example 1: whether depression level is stochastically increasing in education level
# Example 2: whether general health is stochastically increasing in educational level

# For saving results
OUTFILE <- "osm_emp.txt"

# Load files/packages
source("osm.R")
library(ggplot2)
library(ggmosaic)

# Settings for osm()
ALPHA <- 0.05 # FWER level
N <- 1e5      # Draws for computing critical value

# Load data
df <- read.csv(file='osm_emp.csv', fileEncoding='UTF-16LE') # created by adult19_variable_selection.R; raw NHIS 2019 but only selected variables

# age of the adult
age <- df$AGEP_A

# E is educational level, with categories {no HS, HS only, some college, bachelor's, above bachelor's}, coded as 1-5
E <- df$EDUC_A
E[E>=0 & E<=3] <- 21
E[E==4] <- 22
E[E>=5 & E<=7] <- 23
E[E==8] <- 24
E[E>=9 & E<=11] <- 25
E <- E - 20
edu.labels <- c("no-HS","HS","some coll.","bachelor's","grad deg")

# D is depression level, over {none/minimal, mild, moderate, severe}, coded as 1-4
D <- df$PHQCAT_A

# H is general health, with categories from poor to excellent, (re)coded as 1-5
H <- 6 - df$PHSTAT_A

# Generate LaTeX output from results
LaTeX.out.fn <- function(ret, levs, reverse) { # ret=returned by osm(); levs=text vector w/ CDF level names
  cv <- ret$cv
  maxstrlen <- max(nchar(levs))
  str <- sprintf("%%-%ds & %%s \\\\\n", maxstrlen)
  for (i in 1:length(levs)) {
    tmp <- ret$t.statistics[,i]
    comp <- tmp; if (reverse) comp <- -tmp
    cat(sprintf(str, levs[i],
                paste0(sprintf('%10s %10.6f',
                               ifelse(comp > cv,'\\innercell',ifelse(comp < -cv,'','\\outercell')),
                               tmp), collapse=' & ')))
  }
  cat("%\n")
  cat(sprintf("Gray shading: outer confidence set.
Bold: inner confidence set.
Confidence level $%d\\%%$.
Critical value computed using $N=\\numnornd{%d}$ random draws.\n", 
              round(100*(1-ALPHA)), N) )
}

### Example 1: depression & education

# Filter to obs w/ non-missing values and 30<=age<=65
keep.inds <- with(data=df, EDUC_A>=0 & EDUC_A<=11 & PHQCAT_A>=1 & PHQCAT_A<=4 & AGEP_A>=30 & AGEP_A<=65)
sink(file=OUTFILE, append=TRUE)
(ret <- osm(Y=D[keep.inds], X=E[keep.inds], alpha=ALPHA, N=N))
LaTeX.out.fn(ret=ret, levs=c('None/minimal', 'Mild \\& below', 'Moderate \\& below'),
             reverse=FALSE)
sink()

# Plot subgroup proportion
pdf(file='osm_emp.pdf', width=6.5, height=4.7, pointsize=10)
Depression <- factor(D[keep.inds], level=1:4, labels=c("none/minimal","mild","moderate","severe"))
Education <-  factor(E[keep.inds], level=1:5, labels=edu.labels)
p1 <- ggplot() +
  geom_mosaic(aes(x=product(Depression, Education), fill=Depression), offset=0.015) +
  scale_fill_brewer(palette=2) + guides(fill=guide_legend(reverse=TRUE)) + theme_mosaic()
# If want grayscale:
# p1 <- p1 + scale_fill_grey(start=0.8, end=0)
df1 <- ggplot_build(p1)$data[[1]]
df1$pr <- round(100*df1$.wt/sum(df1$.wt), 2)
df1$lab <- paste0(df1$.wt, "; ", df1$pr, "%")
p1 + geom_label(data=df1, size=2,
                aes(x=(xmin+xmax)/2, y=(ymin+ymax)/2, label=lab)) +
  theme(text=element_text(size=10), plot.margin=margin(0,0,0,0)) +
  guides(fill=guide_legend(reverse=TRUE))
dev.off()


### Example 2: general health & education

# Filter to obs w/ non-missing values and 30<=age<=65
keep.inds <- with(data=df, EDUC_A>=0 & EDUC_A<=11 & PHSTAT_A>=1 & PHSTAT_A<=5 & AGEP_A>=30 & AGEP_A<=65)
sink(file=OUTFILE, append=TRUE)
(ret <- osm(Y=H[keep.inds], E[keep.inds], alpha=ALPHA, N=N))
LaTeX.out.fn(ret=ret, levs=c('Poor', 'Fair \\& below', 'Good \\& below', 'Very good \\& below'),
             reverse=TRUE)
sink()

# Plot subgroup proportion
pdf(file='osm_emp_app.pdf', width=6.5, height=4.7, pointsize=10)
Health <- factor (H[keep.inds], level=1:5, labels= c("poor","fair","good","very good","excellent"))
Education <- factor (E[keep.inds], level = 1:5, labels=edu.labels)
p2 <- ggplot() +
  geom_mosaic(aes(x=product(Health, Education), fill=Health),offset=0.015) +
  scale_fill_brewer(palette=2) + guides(fill=guide_legend(reverse=TRUE)) + theme_mosaic()
# If want grayscale for printout friendly:
# p2 <- p2 +scale_fill_grey(start=0.8, end=0)
df2 <- ggplot_build(p2)$data[[1]]
df2$pr <- round(100*df2$.wt/sum(df2$.wt), 2)
df2$lab <- paste0(df2$.wt, "; ", df2$pr, "%")
p2 + geom_label(data=df2, size=2,
                aes(x=(xmin+xmax)/2, y=(ymin+ymax)/2, label=lab)) +
  theme(text=element_text(size=10), plot.margin=margin(0,0,0,0)) +
  guides(fill=guide_legend(reverse=TRUE))
dev.off()

#EOF