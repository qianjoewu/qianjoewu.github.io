#This file contains two parts of supporting functions for the simulation design in the paper. 
#The first part is to support the simulation of Table 1, the size and power of different global test. 
#The second part is to support the simulation of Table 2, the computational cost of different global test

############################################################
# Rolling-window multiple testing simulation supporting functions 
# Methods: HMP, Bonferroni, bootstrap minP (sup-type via minP)
############################################################

## ---------- Utilities ----------

#' Check integerish scalar
#' @param x numeric scalar
#' @param name character, name used in error messages
#' @return invisible(TRUE) or stop
.assert_scalar_int <- function(x, name) {
  if (!is.numeric(x) || length(x) != 1 || !is.finite(x) || x != as.integer(x) || x <= 0) {
    stop(sprintf("'%s' must be a positive integer scalar.", name))
  }
  invisible(TRUE)
}

#' Check numeric vector
#' @param x numeric vector
#' @param name character
#' @return invisible(TRUE) or stop
.assert_numeric_vec <- function(x, name) {
  if (!is.numeric(x) || any(!is.finite(x))) stop(sprintf("'%s' must be finite numeric.", name))
  invisible(TRUE)
}


## ---------- Rolling p-value generators (local tests) ----------

#' Rolling mean test (t-test on mean=0, two-sided)
#'
#' Input:
#'   y: numeric vector length N
#'   m: integer window length
#' Output:
#'   numeric vector p-values length K = N-m+1
roll_pvals_mean_t <- function(y, m) {
  .assert_numeric_vec(y, "y")
  .assert_scalar_int(m, "m")
  N <- length(y)
  K <- N - m + 1L
  if (K <= 0L) stop("m must be <= N.")
  
  # cumulative sums for fast rolling mean/var
  cs1 <- c(0, cumsum(y))
  cs2 <- c(0, cumsum(y * y))
  
  sum1 <- cs1[(m + 1L):(N + 1L)] - cs1[1L:K]
  sum2 <- cs2[(m + 1L):(N + 1L)] - cs2[1L:K]
  
  mean_w <- sum1 / m
  # sample variance with df = m-1
  s2 <- (sum2 - m * mean_w * mean_w) / (m - 1L)
  s2 <- pmax(s2, 0)  # numerical guard
  se <- sqrt(s2 / m)
  
  tstat <- mean_w / se
  # handle zero-variance windows
  tstat[!is.finite(tstat)] <- 0
  
  2 * stats::pt(-abs(tstat), df = m - 1L)
}

#' Rolling Ljung-Box test on serial correlation up to lag h (type="Ljung-Box", fitdf=0)
#'
#' Input:
#'   y: numeric vector length N
#'   m: integer window length
#'   h: integer, number of lags
#' Output:
#'   numeric vector p-values length K = N-m+1
roll_pvals_ljung_box <- function(y, m, h = 5L) {
  .assert_numeric_vec(y, "y")
  .assert_scalar_int(m, "m")
  .assert_scalar_int(h, "h")
  
  N <- length(y)
  K <- N - m + 1L
  if (K <= 0L) stop("m must be <= length(y).")
  if (h >= m) stop("h must be < m for Ljung-Box.")
  
  i <- seq_len(K)
  
  # rolling mean
  cs1 <- c(0, cumsum(y))
  sum_y <- cs1[i + m] - cs1[i]
  mu <- sum_y / m
  
  # rolling gamma0 = sum (y - mu)^2
  cs2 <- c(0, cumsum(y * y))
  sum_y2 <- cs2[i + m] - cs2[i]
  sxx0 <- sum_y2 - m * mu * mu
  sxx0 <- pmax(sxx0, 0)
  
  p <- rep(1, K)
  ok <- (sxx0 > 0)
  
  Q <- numeric(K)
  
  for (k in seq_len(h)) {
    # prod[j] = y[j+k] * y[j],  j = 1..(N-k)
    prod <- y[(k + 1L):N] * y[1L:(N - k)]
    cprod <- c(0, cumsum(prod))  # length (N-k)+1
    
    # For window start i:
    # sum_{t=i+k..i+m-1} y_t y_{t-k}
    # map to prod index j=t-k ranges j=i..i+m-k-1
    sum_y_yk <- cprod[i + (m - k)] - cprod[i]
    
    # sum_{t=i+k..i+m-1} y_t = cs1[i+m] - cs1[i+k]
    sum_y_t  <- cs1[i + m] - cs1[i + k]
    
    # sum_{t=i..i+m-k-1} y_t = cs1[i+m-k] - cs1[i]
    sum_y_tk <- cs1[i + (m - k)] - cs1[i]
    
    # demeaned autocov numerator
    sxxk <- sum_y_yk - mu * sum_y_t - mu * sum_y_tk + (m - k) * mu * mu
    
    r_k <- numeric(K)
    r_k[ok] <- sxxk[ok] / sxx0[ok]
    
    #Q <- Q + (m * (m + 2)) * (r_k * r_k) / (m - k)
    m_eff <- m - k
    Q <- Q + (m_eff * (m_eff + 2)) * (r_k * r_k) / (m_eff - k)
  }
  
  p[ok] <- stats::pchisq(Q[ok], df = h, lower.tail = FALSE)
  p[!is.finite(p)] <- NA_real_
  p
}




#' Rolling variance test: test sigma^2 = sigma0^2 via chi-square (normality assumed)
#'
#' Input:
#'   y: numeric vector length N
#'   m: integer window length
#'   sigma0: numeric > 0, null variance level
#' Output:
#'   numeric vector p-values length K
roll_pvals_var_chisq <- function(y, m, sigma0 = 1) {
  .assert_numeric_vec(y, "y")
  .assert_scalar_int(m, "m")
  if (!is.numeric(sigma0) || length(sigma0) != 1 || !is.finite(sigma0) || sigma0 <= 0) {
    stop("'sigma0' must be a positive finite scalar.")
  }
  N <- length(y)
  K <- N - m + 1L
  if (K <= 0L) stop("m must be <= N.")
  
  cs1 <- c(0, cumsum(y))
  cs2 <- c(0, cumsum(y * y))
  
  sum1 <- cs1[(m + 1L):(N + 1L)] - cs1[1L:K]
  sum2 <- cs2[(m + 1L):(N + 1L)] - cs2[1L:K]
  
  mean_w <- sum1 / m
  s2 <- (sum2 - m * mean_w * mean_w) / (m - 1L)
  s2 <- pmax(s2, 0)
  
  stat <- (m - 1L) * s2 / (sigma0^2)
  P <- stats::pchisq(stat, df = m - 1L)
  p <- 2 * pmin(P, 1 - P)
  p[!is.finite(p)] <- NA_real_
  p
}


############################################################
# Simple, fast Rolling ADF(1) (lag=1 only), NO packages
# p-values via Monte Carlo null CDF under random-walk H0
# with both in-session cache + on-disk cache (.rds files).
############################################################



## ---------- ADF(1) tau statistic for ONE window (lag=1 only) ----------
# Model (type="none"):
#   dy_t = beta*y_{t-1} + gamma*dy_{t-1} + e_t
# Model (type="drift"):
#   dy_t = a + beta*y_{t-1} + gamma*dy_{t-1} + e_t
# Output: tau = t-stat of beta (coefficient on y_{t-1})
adf1_tau <- function(seg, type = c("none", "drift")) {
  type <- match.arg(type)
  m <- length(seg)
  if (m < 6L) return(NA_real_)  # need enough df
  
  dy <- diff(seg)         # length m-1
  y_l1 <- seg[-m]         # length m-1
  
  # lag=1: effective sample t = 3..m, size = m-2
  y_dep <- dy[-1L]                 # dy_t
  y_l1e <- y_l1[-1L]               # y_{t-1}
  dy_l1 <- dy[-(m - 1L)]           # dy_{t-1}
  
  if (type == "drift") {
    X <- cbind(1, y_l1e, dy_l1)
    bpos <- 2L
  } else {
    X <- cbind(y_l1e, dy_l1)
    bpos <- 1L
  }
  
  fit <- .lm.fit(X, y_dep)
  pX <- ncol(X)
  
  if (!is.null(fit$rank) && fit$rank < pX) return(NA_real_)
  df_res <- length(y_dep) - pX
  if (df_res <= 0L) return(NA_real_)
  
  s2 <- sum(fit$residuals^2) / df_res
  
  Qr <- fit$qr
  Rmat <- if (is.list(Qr) && !is.null(Qr$qr)) {
    Qr$qr[1L:pX, 1L:pX, drop = FALSE]
  } else {
    Qr[1L:pX, 1L:pX, drop = FALSE]
  }
  XtX_inv <- chol2inv(Rmat)
  
  se_b <- sqrt(s2 * XtX_inv[bpos, bpos])
  if (!is.finite(se_b) || se_b <= 0) return(NA_real_)
  
  fit$coefficients[bpos] / se_b
}

## ---------- Cache (session + disk) for null tau distribution ----------
.adf1_cache_env <- new.env(parent = emptyenv())

#在“样本长度为 m 的单个时间序列”上，模拟 ADF(1) 的 tau 统计量的有限样本分布。
# Get null tau samples for given (m, type, M, seed), sorted ascending.
# Null DGP is random walk: y_t = y_{t-1} + eps_t, eps_t ~ N(0,1).
get_adf1_null_tau <- function(m,
                              type = c("none", "drift"),
                              M = 50000L,
                              seed = 1L,
                              cache_dir = "adf_null_cache") {
  type <- match.arg(type)
  .assert_scalar_int(m, "m")
  .assert_scalar_int(M, "M")
  .assert_scalar_int(seed, "seed")
  
  if (!dir.exists(cache_dir)) dir.create(cache_dir, recursive = TRUE, showWarnings = FALSE)
  
  fn <- file.path(cache_dir, sprintf("adf1_tau_null_m%d_%s_M%d_seed%d.rds", m, type, M, seed))
  key <- sprintf("m=%d|type=%s|M=%d|seed=%d", m, type, M, seed)
  
  # 1) Session cache FIRST (avoid repeated readRDS in the same R session)
  if (exists(key, envir = .adf1_cache_env, inherits = FALSE)) {
    return(get(key, envir = .adf1_cache_env, inherits = FALSE))
  }
  
  # 2) Disk cache SECOND (read once, then store in session cache)
  if (file.exists(fn)) {
    tau <- readRDS(fn)
    assign(key, tau, envir = .adf1_cache_env)
    return(tau)
  }
  
  # 3) Build
  set.seed(seed)
  tau <- vapply(seq_len(M), function(j) {
    y <- cumsum(rnorm(m))
    adf1_tau(y, type = type)
  }, numeric(1))
  
  tau <- tau[is.finite(tau)]
  if (length(tau) < max(100L, as.integer(0.2 * M))) {
    stop("Too few finite null taus; increase m or check code.")
  }
  tau <- sort(tau)
  
  assign(key, tau, envir = .adf1_cache_env)
  saveRDS(tau, fn)
  
  tau
}

# Fast rolling ADF(1) tau-stat (lag=1 only), supports type="none" and "drift"
# No .lm.fit, no solve.
#
# Model on each window y[s:(s+m-1)], effective sample n = m-2 (t = s+2..s+m-1):
#   type="none" : dy_t = beta*y_{t-1} + gamma*dy_{t-1} + e_t
#   type="drift": dy_t = a + beta*y_{t-1} + gamma*dy_{t-1} + e_t
#
# Output: numeric vector tau length K = N-m+1

roll_tau_adf1_fast2 <- function(y, m, type = c("none", "drift")) {
  .assert_numeric_vec(y, "y")
  .assert_scalar_int(m, "m")
  type <- match.arg(type)
  
  N <- length(y)
  K <- N - m + 1L
  if (K <= 0L) stop("m must be <= length(y).")
  n <- m - 2L
  if (n <= 3L) stop("m too small for ADF(1). Need m >= 6.")
  
  # Global aligned series for t = 3..N (length L = N-2):
  # z  = dy_t
  # x1 = y_{t-1}
  # x2 = dy_{t-1}
  dy <- diff(y)                 # length N-1
  z  <- dy[2:(N - 1L)]          # length N-2
  x1 <- y[2:(N - 1L)]           # length N-2
  x2 <- dy[1:(N - 2L)]          # length N-2
  
  L <- N - 2L
  if (length(z) != L) stop("Internal length mismatch.")
  
  ps <- function(v) c(0, cumsum(v))
  get_sum <- function(P, l, r) P[r + 1L] - P[l]
  
  # Prefix sums needed
  Pz    <- ps(z)
  Px1   <- ps(x1)
  Px2   <- ps(x2)
  Pzz   <- ps(z*z)
  Px1x1 <- ps(x1*x1)
  Px2x2 <- ps(x2*x2)
  Px1x2 <- ps(x1*x2)
  Px1z  <- ps(x1*z)
  Px2z  <- ps(x2*z)
  
  tau <- rep(NA_real_, K)
  
  # ----------------------------
  # type == "none": 2 regressors
  # ----------------------------
  if (type == "none") {
    for (s in seq_len(K)) {
      l <- s
      r <- s + n - 1L
      
      S11 <- get_sum(Px1x1, l, r)
      S22 <- get_sum(Px2x2, l, r)
      S12 <- get_sum(Px1x2, l, r)
      
      T1  <- get_sum(Px1z,  l, r)
      T2  <- get_sum(Px2z,  l, r)
      zz  <- get_sum(Pzz,   l, r)
      
      det <- S11*S22 - S12*S12
      if (!is.finite(det) || abs(det) < 1e-12) next
      
      inv11 <-  S22 / det
      inv22 <-  S11 / det
      inv12 <- -S12 / det
      
      beta  <- inv11*T1 + inv12*T2
      gamma <- inv12*T1 + inv22*T2
      
      # RSS = z'z - 2 b'X'z + b'X'X b
      bXtY  <- beta*T1 + gamma*T2
      bXtXb <- beta*(S11*beta + S12*gamma) + gamma*(S12*beta + S22*gamma)
      RSS <- zz - 2*bXtY + bXtXb
      
      df_res <- n - 2L
      if (!is.finite(RSS) || RSS <= 0 || df_res <= 0L) next
      s2 <- RSS / df_res
      
      se_beta <- sqrt(s2 * inv11)
      if (!is.finite(se_beta) || se_beta <= 0) next
      tau[s] <- beta / se_beta
    }
    return(tau)
  }
  
  # ------------------------------------------
  # type == "drift": 3 regressors [1, x1, x2]
  # Closed-form 3x3 inverse via cofactors
  # ------------------------------------------
  for (s in seq_len(K)) {
    l <- s
    r <- s + n - 1L
    
    # XtX entries
    a00 <- n
    a01 <- get_sum(Px1,   l, r)
    a02 <- get_sum(Px2,   l, r)
    a11 <- get_sum(Px1x1, l, r)
    a22 <- get_sum(Px2x2, l, r)
    a12 <- get_sum(Px1x2, l, r)
    
    # X'z entries
    t0 <- get_sum(Pz,   l, r)
    t1 <- get_sum(Px1z, l, r)
    t2 <- get_sum(Px2z, l, r)
    
    zz <- get_sum(Pzz, l, r)
    
    # Symmetric XtX:
    # [a00 a01 a02]
    # [a01 a11 a12]
    # [a02 a12 a22]
    
    # Cofactors (for symmetric matrix, still compute explicitly)
    C00 <-  a11*a22 - a12*a12
    C01 <- -(a01*a22 - a02*a12)
    C02 <-  a01*a12 - a02*a11
    
    C10 <- -(a01*a22 - a02*a12)
    C11 <-  a00*a22 - a02*a02
    C12 <- -(a00*a12 - a01*a02)
    
    C20 <-  a01*a12 - a02*a11
    C21 <- -(a00*a12 - a01*a02)
    C22 <-  a00*a11 - a01*a01
    
    det <- a00*C00 + a01*C01 + a02*C02
    if (!is.finite(det) || abs(det) < 1e-12) next
    inv_det <- 1 / det
    
    # Inverse = (1/det) * adj(XtX) = (1/det) * t(CofactorMatrix)
    inv00 <- C00 * inv_det
    inv01 <- C10 * inv_det
    inv02 <- C20 * inv_det
    inv10 <- C01 * inv_det
    inv11 <- C11 * inv_det   # <- this is Var(beta)/s2 element we need (beta is 2nd regressor)
    inv12 <- C21 * inv_det
    inv20 <- C02 * inv_det
    inv21 <- C12 * inv_det
    inv22 <- C22 * inv_det
    
    # b = inv(XtX) %*% X'z
    a_hat <- inv00*t0 + inv01*t1 + inv02*t2
    beta  <- inv10*t0 + inv11*t1 + inv12*t2
    gamma <- inv20*t0 + inv21*t1 + inv22*t2
    
    # RSS = z'z - 2 b'X'z + b'XtX b
    bXtY <- a_hat*t0 + beta*t1 + gamma*t2
    
    # b'XtX b using symmetric quadratic form
    # = a00 a^2 + a11 b^2 + a22 g^2 + 2 a01 a b + 2 a02 a g + 2 a12 b g
    bXtXb <- a00*a_hat*a_hat + a11*beta*beta + a22*gamma*gamma +
      2*a01*a_hat*beta + 2*a02*a_hat*gamma + 2*a12*beta*gamma
    
    RSS <- zz - 2*bXtY + bXtXb
    
    df_res <- n - 3L
    if (!is.finite(RSS) || RSS <= 0 || df_res <= 0L) next
    s2 <- RSS / df_res
    
    se_beta <- sqrt(s2 * inv11)
    if (!is.finite(se_beta) || se_beta <= 0) next
    tau[s] <- beta / se_beta
  }
  
  tau
}


## ---------- Rolling ADF(1) p-values (left-tail) ----------
# p-value defined as empirical CDF under null:
#   p_i = P( tau* <= tau_obs )
# Smaller tau (more negative) => stronger evidence against unit root.
roll_pvals_adf_fast2 <- function(y, m, type = c("none", "drift"),
                                 M_null = 50000L, seed_null = 1L, cache_dir = "adf_null_cache",
                                 tau_null = NULL) {
  .assert_numeric_vec(y, "y")
  .assert_scalar_int(m, "m")
  .assert_scalar_int(M_null, "M_null")
  .assert_scalar_int(seed_null, "seed_null")
  type <- match.arg(type)
  
  if (is.null(tau_null)) {
    tau_null <- get_adf1_null_tau(m = m, type = type, M = M_null, seed = seed_null, cache_dir = cache_dir)
  }
  L <- length(tau_null)
  
  tau <- roll_tau_adf1_fast2(y, m = m, type = type)
  
  p <- rep(NA_real_, length(tau))
  ok <- is.finite(tau)
  if (any(ok)) {
    idx <- findInterval(tau[ok], tau_null, rightmost.closed = TRUE)  # 0..L
    # 用 super-uniform 版本更稳（不会造成 size 偏大）
    p[ok] <- (idx + 1) / (L + 1)
  }
  p
}


#' Rolling Granger causality test in VAR(1): x -> y
#'
#' Input:
#'   y: numeric vector length N  (the dependent series)
#'   x: numeric vector length N  (the causing series)
#'   m: integer window length
#'   include_const: logical, include intercept in each window regression
#'
#' Output:
#'   numeric vector p-values length K = N-m+1 (H0: coefficient on x_{t-1} in y-eq = 0)
roll_pvals_granger_var1 <- function(y, x, m, include_const = TRUE) {
  .assert_numeric_vec(y, "y")
  .assert_numeric_vec(x, "x")
  if (length(y) != length(x)) stop("y and x must have the same length.")
  .assert_scalar_int(m, "m")
  
  N <- length(y)
  K <- N - m + 1L
  if (K <= 0L) stop("m must be <= N.")
  
  p <- numeric(K)
  
  for (i in seq_len(K)) {
    idx <- i:(i + m - 1L)
    yy <- y[idx]
    xx <- x[idx]
    
    y_t  <- yy[-1L]
    y_l1 <- yy[-m]
    x_l1 <- xx[-m]
    
    if (include_const) {
      X_u <- cbind(1, y_l1, x_l1)
      X_r <- cbind(1, y_l1)
      k_u <- 3L
      k_r <- 2L
    } else {
      X_u <- cbind(y_l1, x_l1)
      X_r <- cbind(y_l1)
      k_u <- 2L
      k_r <- 1L
    }
    
    fit_u <- .lm.fit(X_u, y_t)
    fit_r <- .lm.fit(X_r, y_t)
    
    rss_u <- sum(fit_u$residuals^2)
    rss_r <- sum(fit_r$residuals^2)
    
    q <- k_u - k_r           # number of restrictions (=1)
    df2 <- length(y_t) - k_u # denominator df
    
    # guard against numerical issues
    if (!is.finite(rss_u) || !is.finite(rss_r) || rss_u <= 0 || df2 <= 0) {
      p[i] <- NA_real_
    } else {
      Fval <- ((rss_r - rss_u) / q) / (rss_u / df2)
      if (!is.finite(Fval) || Fval < 0) Fval <- 0
      p[i] <- stats::pf(Fval, df1 = q, df2 = df2, lower.tail = FALSE)
    }
  }
  
  p
}



## ---------- Global multiple-testing / combination methods ----------

#' HMP global p-value 
#'
#' Input:
#'   p: numeric vector of p-values (length K)
#' Output:
#'   numeric scalar p_hmp in [0,1]
#' Note: this returns the combined p-value


HMP_combined_p = function(p){
  .assert_numeric_vec(p, "p")
  if (any(p <= 0)) {
    # cap very small p to avoid inf; keep deterministic
    p <- pmax(p, 1e-300)
  }
  if (any(p > 1)) stop("p-values must be <= 1.")
  K = length(p) 
  Eu = 0.5772157
  loc_para = log(K) + 1-Eu+log(pi/2)
  
  HMP = mean(1/p)
  combined_p_HMP= 1-FMStable::pEstable(HMP, FMStable::setParam(alpha = 1, logscale = log(pi/2), location = loc_para, pm = 0))
  return(combined_p_HMP)
}





#' Bonferroni global decision + window decisions
#'
#' Input:
#'   p: numeric vector p-values
#'   alpha: numeric in (0,1)
#' Output:
#'   list with:
#'     reject_global: logical
#'     p_global: numeric scalar (Bonferroni-adjusted minP)
#'     reject_windows: logical vector
bonferroni_rule <- function(p, alpha = 0.05) {
  .assert_numeric_vec(p, "p")
  if (!is.numeric(alpha) || length(alpha) != 1 || alpha <= 0 || alpha >= 1) stop("bad alpha")
  K <- length(p)
  pmin <- min(p, na.rm = TRUE)
  p_global <- min(1, K * pmin)
  reject_windows <- p <= (alpha / K)
  list(reject_global = (p_global <= alpha), p_global = p_global, reject_windows = reject_windows)
}


## ---------- Bootstrap sup-type via minP (parametric bootstrap) ----------

#' Fit null model for parametric bootstrap (mean test / var test / LB)
#'
#' Input:
#'   y: numeric vector
#'   null_type: character, one of c("wn", "mean0_norm", "var_norm")
#'   sigma0: optional positive scalar; required when null_type="var_norm"
#' Output:
#'   list of fitted parameters for simulation under H0
fit_null_model <- function(y, null_type = c("wn", "mean0_norm", "var_norm", "adf_rw"), sigma0=NULL) {
  .assert_numeric_vec(y, "y")
  null_type <- match.arg(null_type)
  
  if (null_type == "wn") {
    # Ljung-Box test
    # White noise with estimated variance
    list(type = "wn", mu = 0, sigma = stats::sd(y))
  } else if (null_type == "mean0_norm") {
    # Normal with mean fixed at 0, variance estimated
    list(type = "mean0_norm", mu = 0, sigma = stats::sd(y))
  } else if (null_type == "var_norm"){
    # Variance test null: enforce sigma = sigma0 (strictly matches H0)
    if (is.null(sigma0) || !is.numeric(sigma0) || length(sigma0) != 1 || !is.finite(sigma0) || sigma0 <= 0) {
      stop("For null_type='var_norm', you must provide a positive scalar sigma0.")
    }
    # mean under H0: pick 0 (matches your DGP). If you prefer, use mean(y).
    list(type = "var_norm", mu = 0, sigma = sigma0)
  } else if (null_type == "adf_rw") {
    # Random walk null for ADF bootstrap: y_t = y_{t-1} + eps_t
    # If you want fixed sigma=1 in simulation, set s <- 1
    dy <- diff(y)
    s <- stats::sd(dy)
    if (!is.finite(s) || s <= 0) s <- 1
    list(type = "adf_rw", sigma_eps = s)
  } else {
    stop("Unknown null_type.")
  }
}

fit_null_model_var1_granger <- function(y, x, include_const = TRUE) {
  .assert_numeric_vec(y, "y")
  .assert_numeric_vec(x, "x")
  if (length(y) != length(x)) stop("y and x must have the same length.")
  N <- length(y)
  if (N < 5) stop("Sample too short for VAR(1) fit.")
  
  # build lagged matrices on full sample: t = 2..N
  y_t  <- y[-1L]
  x_t  <- x[-1L]
  y_l1 <- y[-N]
  x_l1 <- x[-N]
  
  if (include_const) {
    # restricted y-eq: y_t ~ 1 + y_{t-1}
    fit_y <- lm(y_t ~ y_l1)
    # x-eq unrestricted: x_t ~ 1 + y_{t-1} + x_{t-1}
    fit_x <- lm(x_t ~ y_l1 + x_l1)
  } else {
    fit_y <- lm(y_t ~ 0 + y_l1)
    fit_x <- lm(x_t ~ 0 + y_l1 + x_l1)
  }
  
  # coefficients
  by <- coef(fit_y)
  bx <- coef(fit_x)
  
  # pack into VAR(1): Z_t = c + A Z_{t-1} + u_t, Z_t = (y_t, x_t)'
  # A is 2x2: rows correspond to equations (y, x); cols correspond to lags (y_{t-1}, x_{t-1})
  if (include_const) {
    cvec <- c(by[1], bx[1])
    A <- rbind(
      c(by["y_l1"], 0.0),              # y-eq: coefficient on x_l1 forced to 0
      c(bx["y_l1"], bx["x_l1"])
    )
  } else {
    cvec <- c(0.0, 0.0)
    A <- rbind(
      c(by["y_l1"], 0.0),
      c(bx["y_l1"], bx["x_l1"])
    )
  }
  
  # residuals and covariance
  uy <- resid(fit_y)
  ux <- resid(fit_x)
  U <- cbind(uy, ux)
  Sigma <- stats::cov(U)
  
  list(type = "var1_granger_null_xy",
       include_const = include_const,
       c = cvec,
       A = A,
       Sigma = Sigma)
}

#' Simulate from fitted null model   ########how about residuals?
#'
#' Input:
#'   fit: list from fit_null_model()
#'   N: integer sample size
#' Output:
#'   numeric vector y_star length N
sim_from_null <- function(fit, N) {
  .assert_scalar_int(N, "N")

  if (fit$type %in% c("wn", "mean0_norm", "var_norm")) {
    return(stats::rnorm(N, mean = fit$mu, sd = fit$sigma))
  } 
  if (fit$type == "adf_rw") {
    # random walk: y_t = y_{t-1} + eps_t
    eps <- stats::rnorm(N, mean = 0, sd = fit$sigma_eps)
    y <- cumsum(eps)
    return(y)
  }
  stop("Unknown fit$type in sim_from_null().")
}


sim_from_null_var1_granger <- function(fit, N) {
  .assert_scalar_int(N, "N")

  Z <- matrix(0, nrow = N, ncol = 2)
  
  # start at 0; you can also start from stationary mean if you like
  Sigma <- fit$Sigma
  Sigma <- Sigma + 1e-8 * diag(2)
  L <- chol(Sigma)

  for (t in 2:N) {
    z <- rnorm(2)
    eps <- as.numeric(L %*% z)
    Z[t, ] <- fit$c + fit$A %*% Z[t - 1, ] + eps
  }
  
  list(y = Z[, 1], x = Z[, 2])
}

#' Bootstrap-calibrated global p-value based on minP (sup-type)
#'
#' Input:
#'   p_obs: numeric vector of observed rolling p-values
#'   y_obs: numeric vector observed data (used to fit null)
#'   N: integer length(y_obs)
#'   B: integer bootstrap replications
#'   alpha: numeric, not needed for p-value but used optionally for decision
#'   roll_fun: function(y, m, ...) -> p-values
#'   roll_args: list of extra args passed to roll_fun (must include m, possibly others)
#'   null_type: character passed to fit_null_model
#'   seed_base: integer base seed to keep reproducible
#' Output:
#'   list with:
#'     p_global_boot: numeric scalar bootstrap p-value
#'     crit_minP: numeric scalar alpha critical value for minP (optional summary)
boot_minP_global <- function(p_obs, y_obs, N, B, alpha,
                             roll_fun, roll_args,
                             null_type,
                             seed_base, n_cores) {

  .assert_numeric_vec(p_obs, "p_obs")
  .assert_numeric_vec(y_obs, "y_obs")
  .assert_scalar_int(N, "N")
  .assert_scalar_int(B, "B")
  if (!is.numeric(alpha) || length(alpha) != 1 || alpha <= 0 || alpha >= 1) stop("bad alpha")
  .assert_scalar_int(seed_base, "seed_base")
  
  if (.Platform$OS.type == "windows" && n_cores > 1L) {
    n_cores <- 1L
    message("Windows detected: set n_cores = 1 (mclapply does not support >1 cores on Windows).")
  }
  
  minP_obs <- min(p_obs, na.rm = TRUE)
  
  sigma0_arg <- NULL
  if (!is.null(roll_args$sigma0)) sigma0_arg <- roll_args$sigma0
  fit <- fit_null_model(y_obs, null_type = null_type, sigma0 = sigma0_arg)
  
  
  minP_star <- unlist(parallel::mclapply(seq_len(B), function(b) {
    sb <- as.integer(((seed_base + b) %% .Machine$integer.max))
    if (sb <= 0L) sb <- 1L
    set.seed(sb)
    
    y_star <- sim_from_null(fit, N = N)
    p_star <- do.call(roll_fun, c(list(y = y_star), roll_args))
    min(p_star, na.rm = TRUE)
  }, mc.cores = n_cores))
  
  
  # bootstrap p-value for minP: P(minP* <= minP_obs)
  p_global_boot <- mean(minP_star <= minP_obs, na.rm = TRUE)
  
  # also report alpha critical value of minP if you want
  crit <- stats::quantile(minP_star, probs = alpha, na.rm = TRUE, type = 8)
  
  list(p_global_boot = p_global_boot, crit_minP = as.numeric(crit), minP_obs = minP_obs)
}


#' Bootstrap global p-value based on minP for bivariate rolling tests (e.g., Granger)
#'
#' Input:
#'   p_obs: observed rolling p-values (length K)
#'   y_obs, x_obs: observed series (length N)
#'   N: length of series
#'   B: bootstrap reps
#'   alpha: level (for crit)
#'   roll_fun: function(y, x, m, ...) -> p-values
#'   roll_args: list including m and include_const etc
#'   null_type: currently supports "var1_granger_null_xy"
#'   seed_base: integer base seed
#'
#' Output:
#'   list(p_global_boot, crit_minP)
boot_minP_global_bivar <- function(p_obs, y_obs, x_obs, N, B, alpha,
                                   roll_fun, roll_args,
                                   null_type, seed_base, n_cores) {
  .assert_numeric_vec(p_obs, "p_obs")
  .assert_numeric_vec(y_obs, "y_obs")
  .assert_numeric_vec(x_obs, "x_obs")
  if (length(y_obs) != length(x_obs)) stop("y_obs and x_obs must have same length.")
  .assert_scalar_int(N, "N")
  .assert_scalar_int(B, "B")
  .assert_scalar_int(seed_base, "seed_base")
  
  if (.Platform$OS.type == "windows" && n_cores > 1L) {
    n_cores <- 1L
    message("Windows detected: set n_cores = 1 (mclapply does not support >1 cores on Windows).")
  }
  
  minP_obs <- min(p_obs, na.rm = TRUE)
  
  if (null_type != "var1_granger_null_xy") stop("Unsupported null_type for bivar bootstrap.")
  
  fit <- fit_null_model_var1_granger(y_obs, x_obs,
                                     include_const = isTRUE(roll_args$include_const))
  
  minP_star <- unlist(parallel::mclapply(seq_len(B), function(b) {
    sb <- as.integer(((seed_base + b) %% .Machine$integer.max))
    if (sb <= 0L) sb <- 1L
    set.seed(sb)
    
    sim <- sim_from_null_var1_granger(fit, N = N)
    p_star <- do.call(roll_fun, c(list(y = sim$y, x = sim$x), roll_args))
    min(p_star, na.rm = TRUE)
  }, mc.cores = n_cores))
  
  
  p_global_boot <- mean(minP_star <= minP_obs, na.rm = TRUE)
  crit <- stats::quantile(minP_star, probs = alpha, na.rm = TRUE, type = 8)
  
  list(p_global_boot = p_global_boot, crit_minP = as.numeric(crit), minP_obs = minP_obs)
}



#######adf bootstrap#######
# Parametric bootstrap minP for rolling ADF(1) MC-calibrated p-values
# H0: random walk y_t = y_{t-1} + eps_t, eps_t ~ N(0,1)
#
# Input:
#   p_obs: observed rolling p-values (from roll_pvals_adf)
#   N: total series length
#   B: bootstrap reps
#   alpha: level for critical value
#   roll_args: list passed to roll_pvals_adf (must include m, type, M_null, seed_null, cache_dir)
#   seed_base: integer base seed for determinism
# Output:
#   list(p_global_boot, crit_minP)
boot_minP_global_adf_rw <- function(p_obs, y_obs, N, B, alpha, roll_args, seed_base) {
  .assert_numeric_vec(p_obs, "p_obs")
  .assert_numeric_vec(y_obs, "y_obs")
  .assert_scalar_int(N, "N")
  .assert_scalar_int(B, "B")
  if (!is.numeric(alpha) || length(alpha) != 1 || alpha <= 0 || alpha >= 1) stop("bad alpha")
  .assert_scalar_int(seed_base, "seed_base")
  
  # Ensure required roll_args exist
  if (is.null(roll_args$m)) stop("roll_args must include m.")
  if (is.null(roll_args$type)) roll_args$type <- "drift"
  if (is.null(roll_args$M_null)) roll_args$M_null <- 50000L
  if (is.null(roll_args$seed_null)) roll_args$seed_null <- 1L
  if (is.null(roll_args$cache_dir)) roll_args$cache_dir <- "adf_null_cache"
  
  # Pre-warm tau-null cache once (so bootstrap loop doesn't try to build it repeatedly)
  # Load tau-null ONCE (from memory cache or disk), then reuse in all bootstrap reps
  tau_null <- get_adf1_null_tau(
    m = as.integer(roll_args$m),
    type = as.character(roll_args$type),
    M = as.integer(roll_args$M_null),
    seed = as.integer(roll_args$seed_null),
    cache_dir = as.character(roll_args$cache_dir)
  )
  
  fit <- fit_null_model(y_obs, null_type = "adf_rw")  # to obtain sigma_eps
  
  minP_obs <- min(p_obs, na.rm = TRUE)
  minP_star <- numeric(B)
  
  
  for (b in seq_len(B)) {
    sb <- as.integer(((seed_base + b) %% .Machine$integer.max))
    if (sb <= 0L) sb <- 1L
    set.seed(sb)
    
    # simulate full length random walk under H0
    # y_star_t = y_star_{t-1} + eps_t, eps_t~N(0, sigma^2) with sigma estimated under H_0
    y_star <- sim_from_null(fit, N = N)
    
    # rolling ADF p-values (MC-CDF based, uses cached tau-null)
    p_star <- roll_pvals_adf_fast2(
      y = y_star,
      m = roll_args$m,
      type = roll_args$type,
      M_null = roll_args$M_null,
      seed_null = roll_args$seed_null,
      cache_dir = roll_args$cache_dir,
      tau_null = tau_null
    )
    
    minP_star[b] <- min(p_star, na.rm = TRUE)
  }
  
  p_global_boot <- mean(minP_star <= minP_obs, na.rm = TRUE)
  crit <- stats::quantile(minP_star, probs = alpha, na.rm = TRUE, type = 8)
  
  list(p_global_boot = p_global_boot, crit_minP = as.numeric(crit), minP_obs = minP_obs)
}

## ---------- Data generating processes (DGPs) ----------

#' Generate mean-shift DGP: y_t ~ N(mu_t, 1)
#'
#' Input:
#'   N: integer
#'   delta: numeric, shift size
#'   seg: integer vector length 2 giving [t1, t2] where mu=delta; if NULL => null mu=0
#' Output:
#'   numeric vector y length N
dgp_mean_shift <- function(N, delta = 0, seg = NULL) {
  .assert_scalar_int(N, "N")

  mu <- rep(0, N)
  if (!is.null(seg)) {
    t1 <- seg[1]; t2 <- seg[2]
    mu[t1:t2] <- delta
  }
  rnorm(N, mean = mu, sd = 1)
}

#' Generate AR(1) segment DGP: piecewise AR(1) with given phi in segment
#'
#' Input:
#'   N: integer
#'   phi0: numeric, baseline phi (often 0 for white noise)
#'   phi1: numeric, phi inside seg
#'   seg: integer vector length 2, [t1, t2]
#' Output:
#'   numeric vector y length N
dgp_piecewise_ar1 <- function(N, phi0 = 0, phi1 = 0.5, seg = NULL) {
  .assert_scalar_int(N, "N")

  eps <- rnorm(N, 0, 1)
  y <- numeric(N)
  y[1] <- eps[1]
  for (t in 2:N) {
    phi <- phi0
    if (!is.null(seg) && t >= seg[1] && t <= seg[2]) phi <- phi1
    y[t] <- phi * y[t - 1] + eps[t]
  }
  y
}


##generate Random Walk
dgp_rw = function(N) {
  .assert_scalar_int(N, "N")
  eps <- rnorm(N, 0, 1)
  y = cumsum(eps) 
  return(y)  
}

#' Generate variance-shift DGP: y_t ~ N(0, sigma_t^2)
#'
#' Input:
#'   N: integer
#'   delta_var: numeric >=0, variance becomes 1+delta_var inside seg
#'   seg: integer vector length 2 or NULL
#' Output:
#'   numeric vector y length N
dgp_var_shift <- function(N, delta_var = 0, seg = NULL) {
  .assert_scalar_int(N, "N")

  sd_t <- rep(1, N)
  if (!is.null(seg)) {
    sd_t[seg[1]:seg[2]] <- sqrt(1 + delta_var)
  }
  rnorm(N, mean = 0, sd = sd_t)
}


#' Bivariate VAR(1) simulator: Z_t = c + A Z_{t-1} + eps_t, eps_t ~ N(0, Sigma)
#'
#' Input:
#'   N: integer length
#'   A: 2x2 matrix
#'   Sigma: 2x2 SPD matrix
#'   c: numeric length 2 intercept
#' Output:
#'   list(y=..., x=...)
dgp_var1_bivar <- function(N, A, Sigma, c = c(0, 0)) {
  .assert_scalar_int(N, "N")
  if (!is.matrix(A) || any(dim(A) != c(2, 2))) stop("A must be 2x2.")
  if (!is.matrix(Sigma) || any(dim(Sigma) != c(2, 2))) stop("Sigma must be 2x2.")
  
  Sigma <- Sigma + 1e-8 * diag(2)
  L <- chol(Sigma)
  
  Z <- matrix(0, nrow = N, ncol = 2)
  
  # no burn: start at unconditional mean (more stable than 0)
  mu <- solve(diag(2) - A + 1e-8 * diag(2), c)
  Z[1, ] <- as.numeric(mu)
  
  for (t in 2:N) {
    eps <- as.numeric(L %*% rnorm(2))
    Z[t, ] <- c + A %*% Z[t - 1, ] + eps
  }
  
  list(y = Z[, 1], x = Z[, 2])
}


## ---------- Scenario runner (one replication) ----------

#' Run one Monte Carlo replication for a given scenario
#'
#' Input:
#'   scenario: list describing DGP and test type
#'     required fields:
#'       name: character scenario name
#'       dgp_fun: function(N, ..., seed) -> y
#'       dgp_args: list of args passed to dgp_fun (excluding N and seed)
#'       roll_fun: function(y, m, ...) -> p-values
#'       roll_args: list (must include m, plus extra args for roll_fun)
#'       null_type: character for bootstrap null fit (see fit_null_model)
#'   N: integer
#'   alpha: numeric
#'   B_boot: integer bootstrap reps
#'   seed_mc: integer seed for this replication
#'
#' Output:
#'   named list of scalar results, ready to rbind into a data.frame row
run_one_rep <- function(scenario, N, alpha, B_boot, seed_mc, n_cores) {
  .assert_scalar_int(N, "N")
  .assert_scalar_int(B_boot, "B_boot")
  .assert_scalar_int(seed_mc, "seed_mc")
  
  ## 1) simulate data (make RNG deterministic for this replication)
  set.seed(seed_mc)
  
  if (isTRUE(scenario$is_bivar)) {
    dat <- do.call(scenario$dgp_fun, c(list(N = N), scenario$dgp_args))
    y <- dat$y
    x <- dat$x
    if (length(y) != N || length(x) != N) stop("Granger DGP must return y and x of length N.")
  } else {
    y <- do.call(scenario$dgp_fun, c(list(N = N), scenario$dgp_args))
    if (length(y) != N) stop("DGP must return y of length N.")
  }
  
  ## 2) rolling p-values
  if (isTRUE(scenario$is_bivar)) {
    p <- do.call(scenario$roll_fun, c(list(y = y, x = x), scenario$roll_args))
  } else {
    p <- do.call(scenario$roll_fun, c(list(y = y), scenario$roll_args))
  }
  
  if (any(!is.finite(p))) stop("Non-finite p-values produced by rolling test.")
  K <- length(p)
  
  
  ## 3) global methods (same as before)
  p_hmp <- HMP_combined_p(p)
  rej_hmp <- (p_hmp <= alpha)
  
  bon <- bonferroni_rule(p, alpha = alpha)

  ## 4) bootstrap sup-type via minP
  seed_base <- as.integer((seed_mc %% .Machine$integer.max))
  if (seed_base <= 0L) seed_base <- 1L
  
  boot <- list(p_global_boot = NA_real_, crit_minP = NA_real_)
  rej_boot_minP <- NA

  if (identical(scenario$null_type, "adf_rw")) {
    # ---- ADF special: RW parametric bootstrap for minP ----
    boot <- boot_minP_global_adf_rw(p_obs = p, y_obs = y, N = N, B = B_boot, alpha = alpha,
                                    roll_args = scenario$roll_args, seed_base = seed_base)
    
    rej_boot_minP <- (boot$p_global_boot <= alpha)
    
  } else if (isTRUE(scenario$is_bivar)) {
      boot <- boot_minP_global_bivar(
        p_obs = p,
        y_obs = y,
        x_obs = x,
        N = N,
        B = B_boot,
        alpha = alpha,
        roll_fun = scenario$roll_fun,
        roll_args = scenario$roll_args,
        null_type = scenario$null_type,
        seed_base = seed_base,
        n_cores = n_cores
      )
      rej_boot_minP <- (boot$p_global_boot <= alpha)
    } else {
      boot <- boot_minP_global(
        p_obs = p,
        y_obs = y,
        N = N,
        B = B_boot,
        alpha = alpha,
        roll_fun = scenario$roll_fun,
        roll_args = scenario$roll_args,
        null_type = scenario$null_type,
        seed_base = seed_base,
        n_cores = n_cores
      )
      rej_boot_minP <- (boot$p_global_boot <= alpha)
    }
    
   
  
  list(
    scenario = scenario$name,
    N = N,
    m = scenario$roll_args$m,
    K = K,
    alpha = alpha,
    
    p_hmp = p_hmp,
    rej_hmp = rej_hmp,
    
    p_bon = bon$p_global,
    rej_bon = bon$reject_global,
    
    p_boot_minP = boot$p_global_boot,
    crit_minP_alpha = boot$crit_minP,
    rej_boot_minP = rej_boot_minP
  )
}
## ---------- Build scenarios ----------

#' Build a list of scenario definitions
#'
#' Input:
#'   N: integer total length (used only to set default segments)
#'   m_grid: integer vector window lengths
#' Output:
#'   list of scenario lists (each used by run_one_rep)
build_scenarios <- function(N, m_grid = c(40L, 60L)) {
  .assert_scalar_int(N, "N")
  m_grid <- as.integer(m_grid)
  
  # choose a default signal segment relative to N
  seg_platform <- c(as.integer(0.35 * N), as.integer(0.55 * N))

  ## ---- Granger causality (VAR(1)) scenarios: x -> y ----
  ## H0: no x_{t-1} in y equation  (A[1,2] = 0)
  ## H1: x Granger-causes y        (A[1,2] = gamma)
  A_null <- matrix(c(0.4, 0.0, 0.2, 0.5), nrow = 2, byrow = TRUE)
  A_alt <- matrix(c(0.4, 0.25, 0.2, 0.5), nrow = 2, byrow = TRUE) # gamma = 0.25 (signal strength)
  Sigma <- matrix(c(1.0, 0.2, 0.2, 1.0), nrow = 2, byrow = TRUE)
  
  scenarios <- list()
  
  for (m in m_grid) {
    
    ## Unit root scenarios with drift
    scenarios[[length(scenarios) + 1L]] <- list(
      name = "adf_drift_null",
      dgp_fun = dgp_rw,
      dgp_args = list(),
      roll_fun = roll_pvals_adf_fast2,
      roll_args = list(
        m = m,
        type = "drift",         # 推荐：finite-sample 更稳
        M_null = 50000L,        # null MC size（一次性）
        seed_null = 1L,
        cache_dir = "adf_null_cache"
      ),
      null_type = "adf_rw"
    )
    
    scenarios[[length(scenarios) + 1L]] <- list(
      name = "adf_drift_alt_phi0.6",
      dgp_fun = dgp_piecewise_ar1,
      dgp_args = list(phi0 = 1.0, phi1 = 0.6, seg = seg_platform),
      roll_fun = roll_pvals_adf_fast2,
      roll_args = list(
        m = m,
        type = "drift",         
        M_null = 50000L,        # null MC size(only used once to compute the adf critical value)
        seed_null = 1L,
        cache_dir = "adf_null_cache"
      ),
      null_type = "adf_rw")
    
    
    # Mean test scenarios
    scenarios[[length(scenarios) + 1L]] <- list(
      name = "mean_null",
      dgp_fun = dgp_mean_shift,
      dgp_args = list(delta = 0, seg = NULL),
      roll_fun = roll_pvals_mean_t,
      roll_args = list(m = m),
      null_type = "mean0_norm"
    )

    scenarios[[length(scenarios) + 1L]] <- list(
      name = "mean_delta0.6",
      dgp_fun = dgp_mean_shift,
      dgp_args = list(delta = 0.6, seg = seg_platform),
      roll_fun = roll_pvals_mean_t,
      roll_args = list(m = m),
      null_type = "mean0_norm"
    )


    ## Ljung-Box scenarios
    scenarios[[length(scenarios) + 1L]] <- list(
      name = "lb_null",
      dgp_fun = dgp_piecewise_ar1,
      dgp_args = list(phi0 = 0, phi1 = 0, seg = NULL),
      roll_fun = roll_pvals_ljung_box,
      roll_args = list(m = m, h = 5L),
      null_type = "wn"
    )

    scenarios[[length(scenarios) + 1L]] <- list(
      name = "lb_phi0.6",
      dgp_fun = dgp_piecewise_ar1,
      dgp_args = list(phi0 = 0, phi1 = 0.6, seg = seg_platform),
      roll_fun = roll_pvals_ljung_box,
      roll_args = list(m = m, h = 5L),
      null_type = "wn"
    )

    ## Variance scenarios
    scenarios[[length(scenarios) + 1L]] <- list(
      name = "var_null",
      dgp_fun = dgp_var_shift,
      dgp_args = list(delta_var = 0, seg = NULL),
      roll_fun = roll_pvals_var_chisq,
      roll_args = list(m = m, sigma0 = 1),
      null_type = "var_norm"
    )

    scenarios[[length(scenarios) + 1L]] <- list(
      name = "var_delta0.8",
      dgp_fun = dgp_var_shift,
      dgp_args = list(delta_var = 0.8, seg = seg_platform),
      roll_fun = roll_pvals_var_chisq,
      roll_args = list(m = m, sigma0 = 1),
      null_type = "var_norm")


    scenarios[[length(scenarios) + 1L]] <- list(
      name = "granger_var1_null_x_to_y",
      is_bivar = TRUE,
      dgp_fun = dgp_var1_bivar,
      dgp_args = list(A = A_null, Sigma = Sigma, c = c(0, 0)),
      roll_fun = roll_pvals_granger_var1,
      roll_args = list(m = m, include_const = TRUE),
      null_type = "var1_granger_null_xy")

    scenarios[[length(scenarios) + 1L]] <- list(
      name = "granger_var1_alt_x_to_y_gamma0.25",
      is_bivar = TRUE,
      dgp_fun = dgp_var1_bivar,
      dgp_args = list(A = A_alt, Sigma = Sigma, c = c(0, 0)),
      roll_fun = roll_pvals_granger_var1,
      roll_args = list(m = m, include_const = TRUE),
      null_type = "var1_granger_null_xy")


  }
  
  scenarios
}

## ---------- Main simulation loop function ----------

#' Run simulation for all scenarios
#'
#' Input:
#'   N: integer
#'   m_grid: integer vector
#'   R: integer Monte Carlo replications
#'   B_boot: integer bootstrap reps
#'   alpha: numeric
#'   seed_master: integer master seed controlling the whole experiment
#'   out_csv: character path for output CSV
#'
#' Output:
#'   data.frame of all replication-level results (invisibly)
run_simulation <- function(N = 400L,
                           m_grid = c(40L, 60L),
                           R = 500L,
                           B_boot = 300L,
                           alpha = 0.05,
                           seed_master = 12345L, n_cores = 1L) {
  .assert_scalar_int(N, "N")
  .assert_scalar_int(R, "R")
  .assert_scalar_int(B_boot, "B_boot")
  .assert_scalar_int(seed_master, "seed_master")
  .assert_scalar_int(n_cores, "n_cores")
  
  scenarios <- build_scenarios(N = N, m_grid = m_grid)
  n_s <- length(scenarios)
  
  
  methods <- c("rej_hmp","rej_bon","rej_boot_minP")
  sum_rej <- matrix(0, nrow = n_s, ncol = length(methods),
                    dimnames = list(NULL, methods))
  n_rep <- integer(n_s)
  
  for (s in seq_len(n_s)) {
    sc <- scenarios[[s]]
    for (r in seq_len(R)) {
      seed_mc <- as.integer(((seed_master + s * 100000 + r) %% .Machine$integer.max))
      if (seed_mc <= 0L) seed_mc <- 1L
      
      one <- run_one_rep(
        scenario = sc,
        N = N,
        alpha = alpha,
        B_boot = B_boot,
        seed_mc = seed_mc, 
        n_cores = n_cores
      )
      n_rep[s] <- n_rep[s] + 1L

      rej_vec <- as.integer(vapply(methods, function(mm) isTRUE(one[[mm]]), logical(1)))
      sum_rej[s, ] <- sum_rej[s, ] + rej_vec
      
      # lightweight progress
      if (r %% 500L == 0L) {
        message(sprintf("Done: scenario %d/%d (%s), rep %d/%d", s, n_s, sc$name, r, R))
      }
    }
  }
  
  summary_df <- data.frame(
    scenario = vapply(scenarios, `[[`, "", "name"),
    N = N,
    m = vapply(scenarios, function(sc) as.integer(sc$roll_args$m), integer(1)),
    R = n_rep,
    rate_hmp = sum_rej[, "rej_hmp"] / n_rep,
    rate_bon = sum_rej[, "rej_bon"] / n_rep,
    rate_boot_minP = sum_rej[, "rej_boot_minP"] / n_rep
  )
  
  return(summary_df)
}


 
############################################################
# Computational cost: to simulate Table 2 in the paper
############################################################

# ============================================================
# Repeat timing 1000 times in single core
 
 # elapsed seconds helper
 .elapsed_sec <- function(expr) as.numeric(system.time(expr)[["elapsed"]])
 
 # compute rolling p-values (reuse your existing scenario structure)
 .compute_pvals <- function(scenario, dat) {
   if (isTRUE(scenario$is_bivar)) {
     p <- do.call(scenario$roll_fun, c(list(y = dat$y, x = dat$x), scenario$roll_args))
   } else {
     p <- do.call(scenario$roll_fun, c(list(y = dat$y), scenario$roll_args))
   }
   if (any(!is.finite(p))) stop(sprintf("Non-finite p-values in scenario '%s'.", scenario$name))
   p
 }
 
 # generate one dataset once, for fair timing across methods
 .generate_one_dataset <- function(scenario, N, seed_data = 1L) {
   set.seed(seed_data)
   if (isTRUE(scenario$is_bivar)) {
     dat <- do.call(scenario$dgp_fun, c(list(N = N), scenario$dgp_args))
     if (length(dat$y) != N || length(dat$x) != N) stop("Bad bivar DGP.")
     dat
   } else {
     y <- do.call(scenario$dgp_fun, c(list(N = N), scenario$dgp_args))
     if (length(y) != N) stop("Bad DGP.")
     list(y = y)
   }
 }
 
 # 1000-rep timing for ONE test
 bench_one_test_repeat <- function(scenario, N, B_boot = 500L, alpha = 0.05,
                                   seed_data = 1L, seed_boot_base = 999L,
                                   n_repeat = 1000L) {
   .assert_scalar_int(N, "N")
   .assert_scalar_int(B_boot, "B_boot")
   .assert_scalar_int(seed_data, "seed_data")
   .assert_scalar_int(seed_boot_base, "seed_boot_base")
   .assert_scalar_int(n_repeat, "n_repeat")
   
   # one fixed dataset
   dat <- .generate_one_dataset(scenario, N = N, seed_data = seed_data)
   
   # for ADF, pre-warm tau-null cache so we don't time building it
   if (identical(scenario$null_type, "adf_rw")) {
     get_adf1_null_tau(
       m = as.integer(scenario$roll_args$m),
       type = as.character(scenario$roll_args$type),
       M = as.integer(scenario$roll_args$M_null),
       seed = as.integer(scenario$roll_args$seed_null),
       cache_dir = as.character(scenario$roll_args$cache_dir)
     )
   }
   
   t_roll <- numeric(n_repeat)
   t_hmp  <- numeric(n_repeat)
   t_boot <- numeric(n_repeat)
   
   for (r in seq_len(n_repeat)) {
     # 1) rolling p-values
     t_roll[r] <- .elapsed_sec({
       p <- .compute_pvals(scenario, dat)
     })
     
     p <- .compute_pvals(scenario, dat)
     
     # 2) HMP
     t_hmp[r] <- .elapsed_sec({
       tmp <- HMP_combined_p(p)
     })
     
     # 3) bootstrap minP (single core)
     seed_base <- as.integer((seed_boot_base + r) %% .Machine$integer.max)
     if (seed_base <= 0L) seed_base <- 1L
     
     t_boot[r] <- .elapsed_sec({
       if (identical(scenario$null_type, "adf_rw")) {
         # ADF special bootstrap (your version without y_obs)
         boot <- boot_minP_global_adf_rw(
           p_obs = p, y_obs = dat$y, N = N, B = B_boot, alpha = alpha,
           roll_args = scenario$roll_args, seed_base = seed_base
         )
       } else if (isTRUE(scenario$is_bivar)) {
         boot <- boot_minP_global_bivar(
           p_obs = p,
           y_obs = dat$y, x_obs = dat$x, N = N,
           B = B_boot, alpha = alpha,
           roll_fun = scenario$roll_fun, roll_args = scenario$roll_args,
           null_type = scenario$null_type,
           seed_base = seed_base,
           n_cores = 1L
         )
       } else {
         boot <- boot_minP_global(
           p_obs = p,
           y_obs = dat$y, N = N,
           B = B_boot, alpha = alpha,
           roll_fun = scenario$roll_fun, roll_args = scenario$roll_args,
           null_type = scenario$null_type,
           seed_base = seed_base,
           n_cores = 1L
         )
       }
       invisible(boot)
     })
   }
   
   # summarize
   data.frame(
     test = scenario$name,
     N = N,
     m = as.integer(scenario$roll_args$m),
     B_boot = B_boot,
     n_repeat = n_repeat,
     
     roll_total = sum(t_roll),
     hmp_total = sum(t_hmp),
     boot_total = sum(t_boot),
     
     stringsAsFactors = FALSE
   )
 }
 
 # The 5 null scenarios considered in the timing 
 build_timing_scenarios <- function(N, m) {
   .assert_scalar_int(N, "N")
   .assert_scalar_int(m, "m")
   
   scs <- build_scenarios(N = N, m_grid = as.integer(m))
   
   # keep only null scenarios based on scenario$name
   nm <- vapply(scs, function(s) if (!is.null(s$name)) s$name else "", character(1))
   keep <- nm %in% c("mean_null", "lb_null", "var_null", "adf_drift_null", "granger_var1_null_x_to_y")
   
   scs_null <- scs[keep]
   
   if (length(scs_null) == 0L) {
     stop("No null scenarios found. Check scenario$name naming (expected to contain 'null').")
   }
   
   scs_null
 }
 
 # run for all 5 tests (your existing builder)
 bench_time_table_repeat <- function(N = 200L, m = 50L, B_boot = 500L, alpha = 0.05,
                                     seed_data = 1L, seed_boot_base = 999L,
                                     n_repeat = 1000L) {
   scs <- build_timing_scenarios(N = N, m = m)
   do.call(rbind, lapply(seq_along(scs), function(j) {
     bench_one_test_repeat(
       scenario = scs[[j]],
       N = N,
       B_boot = B_boot,
       alpha = alpha,
       seed_data = seed_data + 1000L * j,
       seed_boot_base = seed_boot_base + 100000L * j,
       n_repeat = n_repeat
     )
   }))
 }
 
