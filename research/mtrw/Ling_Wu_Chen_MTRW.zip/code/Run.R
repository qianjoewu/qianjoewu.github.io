get_script_dir <- function() {
  cmd <- commandArgs(trailingOnly = FALSE)
  m <- grep("^--file=", cmd)
  if (length(m) > 0) return(dirname(normalizePath(sub("^--file=", "", cmd[m[1]]))))
  if (!is.null(sys.frames()[[1]]$ofile)) return(dirname(normalizePath(sys.frames()[[1]]$ofile)))
  getwd()
}

root <- get_script_dir()

source(file.path(root, "Simulation.R"))

if (!requireNamespace("FMStable", quietly = TRUE)) {
  stop("Package 'FMStable' is required. Please install it via install.packages('FMStable').")
}

# ---- output folders ----
out_dir <- file.path(root, "output")
dir.create(out_dir, showWarnings = FALSE)
dir.create(file.path(out_dir, "tables"), showWarnings = FALSE)
dir.create(file.path(out_dir, "figures"), showWarnings = FALSE)

############################################################
# Simulation Table 1: Size and Power
############################################################

m_grid = 50

# ---- warm up ADF null distributions ----
cache_dir <- file.path(root, "adf_null_cache")
for (m in m_grid) {
  for (tp in c("none","drift")) {
    get_adf1_null_tau(m=m, type=tp, M=50000L, seed=1L, cache_dir=cache_dir)
  }
}

tic=Sys.time()
df <- run_simulation(N=200, m_grid=m_grid, R=1000, B_boot=500, alpha=0.05, seed_master=654321, n_cores = 8)
toc=Sys.time();print(toc-tic) 


sim_path <- file.path(out_dir, "tables", "sim_results.csv")
if (!file.exists(sim_path)) {
  utils::write.csv(df, sim_path, row.names = FALSE)
} else {
  utils::write.table(df, file = sim_path, row.names = FALSE,
                     col.names = FALSE, append = TRUE, sep = ",")
}

############################################################
# Simulation Table 2: Computational Time
############################################################
tic=Sys.time()
tab_time_1000 <- bench_time_table_repeat(
  N = 200, m = 50, B_boot = 500, alpha = 0.05,
  seed_data = 1, seed_boot_base = 999, n_repeat = 1000)
toc=Sys.time()
time_path <- file.path(out_dir, "tables", "timing_table_repeat1000.csv")
utils::write.csv(tab_time_1000, time_path, row.names = FALSE)



############################################################
# Application: Application: SP500 return and IDEMV in rolling-window GC 
############################################################
source(file.path(root, "Application.R"))

need <- c("dplyr", "lubridate", "quantmod", "xts", "zoo", "vars")
for (p in need) {
  if (!requireNamespace(p, quietly = TRUE)) stop("Missing package: ", p)
}
library(dplyr)
library(lubridate)

# ============================================================
# Read or Download SP500 data and IDEMV data
# Weekly construction:
# - SP500 weekly return: log(Close_Friday_Price) - log(Close_Monday_Price)
#   where trading days are restricted to Mon–Fri.
# - IDEMV weekly: Average of daily IDEMV within Mon–Fri of the same week.
# Sample window: (PHE_start - 1 year) to (PHE_end + 1 year)
# ============================================================


# ----------  Set PHE window (US COVID-19 Public Health Emergency) ----------
phe_start <- as.Date("2020-01-31")
phe_end   <- as.Date("2023-05-11")

start_date <- phe_start %m-% years(1)   # 2019-01-31
end_date   <- phe_end   %m+% years(1)   # 2024-05-11

# ----------  Load IDEMV daily (your file) ----------
# Adjust column name below if needed after checking names(idemv_raw)
# locate IDEMV CSV
idemv_csv <- file.path(root, "All_Infectious_EMV_Data.csv")
if (!file.exists(idemv_csv)) stop("Cannot find IDEMV csv. Put it in the project root.")

idemv_raw <- utils::read.csv(idemv_csv)

# Try to robustly create a date column
# Common cases:
# (a) file already has "date"
# (b) file has year/month/day columns
if ("date" %in% names(idemv_raw)) {
  idemv_raw <- idemv_raw %>%
    mutate(date = as.Date(date))
} else if (all(c("year", "month", "day") %in% names(idemv_raw))) {
  idemv_raw <- idemv_raw %>%
    mutate(date = as.Date(sprintf("%04d-%02d-%02d", year, month, day)))
} else {
  stop("Cannot find a usable date column. Please ensure IDEMV file has either 'date' or (year, month, day).")
}

idemv_col <- "daily_infect_emv_index" # IDEMV column name

idemv_daily <- idemv_raw %>%
  transmute(date = date, IDEMV = as.numeric(.data[[idemv_col]])) %>%
  filter(is.finite(IDEMV)) %>%
  filter(date >= start_date, date <= end_date)


# ----------  Read or Download S&P 500 daily close from FRED ----------
sp500_cache <- file.path(root, "SP500_FRED.csv")
if (file.exists(sp500_cache)) {
  spx <- utils::read.csv(sp500_cache)
  spx$date <- as.Date(spx$date)
  spx$spx_close <- as.numeric(spx$spx_close)
} else {
  quantmod::getSymbols("SP500", src = "FRED", auto.assign = TRUE)
  spx <- data.frame(
    date = as.Date(zoo::index(SP500)),
    spx_close = as.numeric(SP500$SP500)
  )
  utils::write.csv(spx, sp500_cache, row.names = FALSE)
}
spx <- spx[!is.na(spx$date) & !is.na(spx$spx_close), ]

spx_daily <- spx %>% filter(is.finite(spx_close),
                            date >= start_date, 
                            date <= end_date)

# ---------- Match daily data on common dates ----------
dat_daily <- inner_join(idemv_daily, spx_daily, by = "date") %>%
  arrange(date)

# ----------  Restrict to Mon–Fri and construct "week id" ----------
# week_start = 1 => Monday-based weeks
dat_mf <- dat_daily %>%
  mutate(
    dow = wday(date, week_start = 1),         # Mon=1,...,Sun=7
    week = floor_date(date, unit = "week", week_start = 1)
  ) %>%
  filter(dow >= 1, dow <= 5) %>%              # keep Mon–Fri only
  arrange(week, date)

# ----------  Weekly IDEMV (Mon–Fri average) ----------
idemv_weekly <- dat_mf %>%
  group_by(week) %>%
  summarise(
    IDEMV_w = mean(IDEMV, na.rm = TRUE),
    n_days_idemv = n(),
    .groups = "drop"
  )

# ----------  Weekly SP500 return (Mon–Fri close log difference) ----------
# Use first trading day close and last trading day close within Mon–Fri of the same week
spx_weekly <- dat_mf %>%
  group_by(week) %>%
  filter(!is.na(spx_close)) %>%
  summarise(
    spx_close_first = first(spx_close),
    spx_close_last  = last(spx_close),
    n_days_spx = n(),
    Return_w = log(spx_close_last) - log(spx_close_first),
    .groups = "drop"
  )

# ----------  Merge weekly series ----------
dat_weekly <- inner_join(spx_weekly, idemv_weekly, by = "week") %>%
  arrange(week)

# standardize IDEMV weekly level (state variable)
dat_weekly <- dat_weekly %>%
  mutate(IDEMV_state = as.numeric(scale(IDEMV_w)))


# Objects ready for rolling Granger code:
Return <- dat_weekly$Return_w
IDEMV <- dat_weekly$IDEMV_state
X <- cbind(Return, IDEMV)
colnames(X) <- c("Return", "IDEMV")

######## GC rolling Analysis ######

m <- 52L
p_hat <- select_lag_each_window(Return, IDEMV, m = m, include_const = TRUE)     

##VAR in vars package 
roll_var_xy <- GC_VAR(data2 = X, m = m, direction = "x_to_y", type = "const", p_hat = p_hat)
roll_var_yx <- GC_VAR(data2 = X, m = m, direction = "y_to_x", type = "const", p_hat = p_hat)
print(HMP_combined_p(roll_var_xy$Pval))
print(HMP_combined_p(roll_var_yx$Pval))
#[1] 0.0004800505 ##[1] 0.01692145


boot_res <- run_bootstrap_lgrid_plot_time(
  y = Return, x = IDEMV,
  dates_w = dat_weekly$week,
  l_grid = m, B = 500, lag_max_default = 5,
  include_const = TRUE, seed = 12345)
# Extract a compact table of bootstrap p-values + critical values:
boot_res$tab
#m p_boot_x_to_y crit_x_to_y maxF_x_to_y p_boot_y_to_x crit_y_to_x maxF_y_to_x
#1 52         0.038     13.0025    14.18593         0.058    11.64261     11.2476
boot_tab_path <- file.path(out_dir, "tables", "App_bootstrap_summary.csv")
utils::write.csv(boot_res$tab, boot_tab_path, row.names = FALSE)

######## Dynamic Plots ######

if (!requireNamespace("ragg", quietly = TRUE)) stop("Missing package: ragg")
out <- file.path(root, "output", "figures", "Figure1.png")
ragg::agg_png(out, width = 2400, height = 1680, res = 300)  

plot_HMP_boot_2x2(
  X = X,  # e.g., cbind(Return, IDEMV)
  week_vec = dat_weekly$week,
  m = 52,
  boot_res = boot_res,
  include_const = TRUE,
  alpha = 0.05,
  ylim_hmp = c(0, 1)
)
dev.off()
out
