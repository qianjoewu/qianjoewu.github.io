
# # Supporting functions for the empirical application.
# # This file is organized as two parts to support the empirical illustration. 
# # The first is the supporting functions.
# # The second is to download and import data of the SP500 stock return and IDEMV index. 

# # ============================================================
# # Part 1:
# # Support functions for rolling-window Granger causality tests
# # and restricted residual bootstrap sup-F, with VAR(p) support.
# #
# # Main user-facing functions:
# #   - select_lag_bic_fullsample()
# #   - GC_VAR()                 # rolling GC via vars::VAR + causality
# #   - granger_casuse_F()       # rolling/window GC F-stat via fast OLS (fixed p)
# #   - var_ols_boot_restricted()
# #   - DGP_boot()
# #   - bootstrap_TS()           # restricted residual bootstrap sup-F
# #
# # Notes:
# #   - All functions assume two series y and x of equal length.
# #   - "x -> y" GC means testing whether lagged x terms jointly enter y-equation.
# #   - include_const controls intercept (default TRUE).
# # ============================================================





# ---------------------------
.assert_numeric_vec <- function(z, name = "x") {
  if (!is.numeric(z) || !is.vector(z)) stop(sprintf("'%s' must be a numeric vector.", name))
  if (any(!is.finite(z))) stop(sprintf("'%s' contains non-finite values.", name))
}

# Build lagged design matrices for bivariate VAR(p), aligned at t = p+1,...,N
.make_lagged_mats <- function(y, x, p, include_const = TRUE) {
  .assert_numeric_vec(y, "y")
  .assert_numeric_vec(x, "x")
  if (length(y) != length(x)) stop("y and x must have the same length.")
  p <- as.integer(p)
  if (p < 1) stop("lag_order p must be >= 1.")
  N <- length(y)
  if (N <= p + 5) stop("Sample too short relative to lag_order p.")
  
  # dependent variables aligned at t = p+1,...,N
  y_dep <- y[(p + 1):N]
  x_dep <- x[(p + 1):N]
  
  # lag matrices: columns are lags 1..p, each of length n
  y_lags <- sapply(1:p, function(l) y[(p + 1 - l):(N - l)])
  x_lags <- sapply(1:p, function(l) x[(p + 1 - l):(N - l)])
  y_lags <- as.matrix(y_lags)
  x_lags <- as.matrix(x_lags)
  
  # Unrestricted design: const + y_lags + x_lags
  Xu <- cbind(y_lags, x_lags)
  if (include_const) Xu <- cbind(1, Xu)
  
  # Restricted design for y-eq under H0 (no x lags): const + y_lags
  Xr_y <- y_lags
  if (include_const) Xr_y <- cbind(1, Xr_y)
  
  list(
    N = N, p = p, n_eff = N-p,
    y_dep = y_dep, x_dep = x_dep,
    y_lags = y_lags, x_lags = x_lags,
    Xu = Xu,
    Xr_y = Xr_y
  )
}

.qr_coef <- function(X, y) {
  as.numeric(qr.solve(X, y))
}

.rss_from_coef <- function(X, y, beta) {
  r <- y - as.numeric(X %*% beta)
  sum(r * r)
}

select_lag_each_window <- function(y, x, m, lag_max_default = 5, include_const = TRUE){
  
  if (!requireNamespace("vars", quietly = TRUE)) stop("Package 'vars' is required.")
  y <- as.numeric(y); x <- as.numeric(x)
  if (length(y) != length(x)) stop("y and x must have the same length.")
  N <- length(y)
  m <- as.integer(m)
  if (N < m) stop("T must be >= m.")
  
  type_var <- if (include_const) "const" else "none"
  
  nW <- N - m + 1L
  p_hat <- integer(nW)
  
  for (w in 1:nW) {
    yw <- y[w:(w + m - 1L)]
    xw <- x[w:(w + m - 1L)]
    
    # VARselect returns a named vector selection; [3] is SC(n) in your code
    p_hat[w] <- as.integer(vars::VARselect(cbind(yw, xw), lag.max = lag_max_default,
                                           type = type_var)$selection["SC(n)"] )
  }
  p_hat
}


# ---------------------------
# Window GC F-stat and p-value via VAR()
# Rolling-window Granger causality test using VAR() and causality() functions in the vars package
# direction: "x_to_y" tests x -> y (cause is column 2 if data2 columns are (y, x))
GC_VAR <- function(data2, m, direction = c("x_to_y", "y_to_x"), type = "const", p_hat) {
  direction <- match.arg(direction)
  if (!requireNamespace("vars", quietly = TRUE)) stop("Package 'vars' is required.")
  if (!is.matrix(data2) && !is.data.frame(data2)) stop("data2 must be a matrix/data.frame with 2 columns.")
  if (ncol(data2) != 2) stop("data2 must have exactly 2 columns.")
  n <- nrow(data2)
  m <- as.integer(m)
  if (n < m) stop("nrow(data2) must be >= m.")
  nW <- n - m + 1
  
  if (missing(p_hat) || is.null(p_hat)) stop("p_hat is required. Compute it first.")
  p_hat <- as.integer(p_hat)
  if (length(p_hat) != nW) stop("p_hat must have length nW = nrow(data2) - m + 1.")
  if (any(!is.finite(p_hat)) || any(p_hat < 1)) stop("p_hat must be positive integers.")
  
  # Ensure colnames exist for causality()
  if (is.null(colnames(data2))) colnames(data2) <- c("y", "x")
  cause_name <- if (direction == "x_to_y") colnames(data2)[2] else colnames(data2)[1]
  
  Fstat <- rep(NA_real_, nW)
  Pval  <- rep(NA_real_, nW)
  for (i in seq_len(nW)) {
    win <- data2[i:(i + m - 1), , drop = FALSE]
    fit <- vars::VAR(win, p = p_hat[i], type = type)
    gr  <- vars::causality(fit, cause = cause_name)$Granger
    Fstat[i] <- as.numeric(gr$statistic)
    Pval[i]  <- as.numeric(gr$p.value)
  }
  
  list(Fstat = Fstat, Pval = Pval, m = m, direction = direction, type = type)
}

# ---------------------------
# Window GC F-stat via fast OLS
# Compute Granger causality F-stat and p-value for x -> y in a single sample segment
# Uses OLS on y-equation only: unrestricted vs restricted (drop x lags)
granger_casuse_F <- function(y, x, lag_order, include_const = TRUE) {
  p <- as.integer(lag_order)
  mats <- .make_lagged_mats(y, x, p, include_const = include_const)
  
  # Unrestricted y eq
  beta_u <- .qr_coef(mats$Xu, mats$y_dep)
  rss_u  <- .rss_from_coef(mats$Xu, mats$y_dep, beta_u)
  
  # Restricted y eq
  beta_r <- .qr_coef(mats$Xr_y, mats$y_dep)
  rss_r  <- .rss_from_coef(mats$Xr_y, mats$y_dep, beta_r)
  
  n_obs <- mats$n_eff
  k_u   <- ncol(mats$Xu) #unrestricted 模型里的参数个数
  df1 <- p
  df2 <- n_obs - k_u
  if (df2 <= 0) stop("df2 <= 0. Increase window length m or reduce lag_order.")
  
  num <- rss_r - rss_u
  if (num < 0) num <- 0
  Fval <- (num / df1) / (rss_u / df2)
  pval <- 1 - pf(Fval, df1 = df1, df2 = df2)
  
  list(F_val = as.numeric(Fval), p_value = as.numeric(pval), df1 = df1, df2 = df2)
}




## Multiple test: returns the combined p-value
HMP_combined_p = function(p_values){
  if (any(p_values <= 0)) {
    # cap very small p to avoid inf; keep deterministic
    p_values <- pmax(p_values, 1e-300)
  }
  if (any(p_values > 1)) stop("p-values must be <= 1.")
  
  Eu = 0.5772157
  HMP = mean(1/p_values)
  combined_p_HMP= 1-FMStable::pEstable(HMP, FMStable::setParam(alpha = 1, logscale = log(pi/2),
                                           location = log(length(p_values)) + 1-Eu+log(pi/2), pm = 0))
  return(combined_p_HMP)
}


# Rolling-window Granger causality (OLS-based), fixed lag p
# direction = "x_to_y" tests x -> y (x lags in y equation)
# direction = "y_to_x" tests y -> x
GC_OLS_roll <- function(y, x, m, include_const = TRUE, direction = c("x_to_y", "y_to_x"), p_hat) {
  
  y <- as.numeric(y); x <- as.numeric(x)
  if (length(y) != length(x)) stop("y and x must have the same length.")
  N <- length(y)
  m <- as.integer(m)
  if (N < m) stop("T must be >= m.")
  nW <- N - m + 1L
  
  if (missing(p_hat) || is.null(p_hat)) stop("p_hat is required. Compute it first via select_lag_each_window().")
  p_hat <- as.integer(p_hat)
  if (length(p_hat) != nW) stop("p_hat must have length nW = N - m + 1.")
  if (any(!is.finite(p_hat)) || any(p_hat < 1)) stop("p_hat must be positive integers.")
  
  
  # swap to reuse granger_casuse_F which tests x -> y
  direction <- match.arg(direction)
  if (direction == "y_to_x") {
    tmp <- y; y <- x; x <- tmp
  }
  
  Fstat <- numeric(nW)
  Pval  <- numeric(nW)
  for (w in 1:nW) {
    yw <- y[w:(w + m - 1L)]
    xw <- x[w:(w + m - 1L)]
    out <- granger_casuse_F(yw, xw, lag_order=p_hat[w], include_const = include_const)
    Fstat[w] <- out$F_val
    Pval[w]  <- out$p_value
  }
  
  list(Fstat = Fstat, Pval = Pval, p_hat = p_hat, m = m, direction = direction, include_const = include_const)
}



# ---------------------------
# Restricted bootstrap fit under H0 (no x lags in y equation)
# Fit restricted model under H0 on the full sample:
#   y_t = c_y + sum a_yy[l]*y_{t-l} + e_y,t
#   x_t = c_x + sum a_xy[l]*y_{t-l} + sum a_xx[l]*x_{t-l} + e_x,t
# Returns coefficient blocks + residual vectors for resampling.
var_ols_boot_restricted <- function(y, x, lag_order, include_const = TRUE) {
  p <- as.integer(lag_order)
  mats <- .make_lagged_mats(y, x, p, include_const = include_const)
  
  # x-equation unrestricted: const + y_lags + x_lags
  beta_x_u <- .qr_coef(mats$Xu, mats$x_dep)
  res_x <- mats$x_dep - as.numeric(mats$Xu %*% beta_x_u)
  
  # y-equation restricted: const + y_lags
  beta_y_r <- .qr_coef(mats$Xr_y, mats$y_dep)
  res_y <- mats$y_dep - as.numeric(mats$Xr_y %*% beta_y_r)
  
  # Unpack coefficient blocks for recursion
  idx <- 1L
  if (include_const) {
    c_x <- beta_x_u[idx]; idx <- idx + 1L
  } else {
    c_x <- 0
  }
  a_xy <- beta_x_u[idx:(idx + p - 1L)]; idx <- idx + p
  a_xx <- beta_x_u[idx:(idx + p - 1L)]
  
  idx <- 1L
  if (include_const) {
    c_y <- beta_y_r[idx]; idx <- idx + 1L
  } else {
    c_y <- 0
  }
  a_yy <- beta_y_r[idx:(idx + p - 1L)]
  
  list(
    p = p,
    include_const = include_const,
    c_y = c_y, a_yy = a_yy,
    c_x = c_x, a_xy = a_xy, a_xx = a_xx,
    resid = cbind(res_y, res_x),  # columns: (y_res, x_res), aligned t=p+1..T
    init_y = y[1:p],
    init_x = x[1:p]
  )
}

# ---------------------------
# DGP_boot: generate pseudo sample under restricted DGP using resampled residuals
# E_star must be (M-p) x 2, columns are (y_res, x_res) resampled as vectors
DGP_boot <- function(fit0, M) {
  if (!is.list(fit0)) stop("fit0 must be the output of var_ols_boot_restricted().")
  
  p <- fit0$p
  E <- fit0$resid ## original residual matrix: (n_eff x 2)
  n_eff <- nrow(E)
  
  
  ##resample residuals with replacement with length M - p
  idx <- sample.int(n_eff, size = M - p, replace = TRUE)
  E_star <- E[idx, , drop = FALSE]
  
  y_star <- numeric(M)
  x_star <- numeric(M)
  y_star[1:p] <- fit0$init_y
  x_star[1:p] <- fit0$init_x
  
  c_y <- fit0$c_y
  a_yy <- fit0$a_yy
  c_x <- fit0$c_x
  a_xy <- fit0$a_xy
  a_xx <- fit0$a_xx
  
  for (t in (p + 1L):M) {
    ylag <- y_star[(t - 1L):(t - p)]
    xlag <- x_star[(t - 1L):(t - p)]
    
    y_star[t] <- c_y + sum(a_yy * ylag) + E_star[t - p, 1]
    x_star[t] <- c_x + sum(a_xy * ylag) + sum(a_xx * xlag) + E_star[t - p, 2]
  }
  
  list(y = y_star, x = x_star)
}

# ---------------------------
# bootstrap_TS_fast: restricted residual bootstrap sup-F for rolling GC (x -> y)

## Build prefix sums for a given p
## returns:
##   Sxx_u: k_u x k_u x (T_eff+1)
##   Sxy_u: k_u x (T_eff+1)
##   Sxx_r: k_r x k_r x (T_eff+1)
##   Sxy_r: k_r x (T_eff+1)
##   Syy:   (T_eff+1)
## plus dims and T_eff
.prep_prefix_onep <- function(y, x, p, include_const) {
  y <- as.numeric(y); x <- as.numeric(x)
  L <- length(y)
  if (length(x) != L) stop("y and x length mismatch.")
  p <- as.integer(p)
  if (p < 1L) stop("p must be >= 1.")
  if (L <= p + 2L) stop("series too short for p.")
  
  T_eff <- L - p  ## observations used in regression for this p
  yresp <- y[(p + 1L):L]
  
  ## lag matrices: each is T_eff x p
  ## ylag[,1] is y_{t-1}, ylag[,p] is y_{t-p}
  ylag <- matrix(0.0, nrow = T_eff, ncol = p)
  xlag <- matrix(0.0, nrow = T_eff, ncol = p)
  for (j in 1:p) {
    ylag[, j] <- y[(p + 1L - j):(L - j)]
    xlag[, j] <- x[(p + 1L - j):(L - j)]
  }
  
  if (isTRUE(include_const)) {
    Zu <- cbind(1.0, ylag, xlag)   ## unrestricted
    Zr <- cbind(1.0, ylag)        ## restricted
  } else {
    Zu <- cbind(ylag, xlag)
    Zr <- ylag
  }
  
  k_u <- ncol(Zu)
  k_r <- ncol(Zr)
  
  ## prefix arrays
  Sxx_u <- array(0.0, dim = c(k_u, k_u, T_eff + 1L))
  Sxy_u <- matrix(0.0, nrow = k_u, ncol = T_eff + 1L)
  Sxx_r <- array(0.0, dim = c(k_r, k_r, T_eff + 1L))
  Sxy_r <- matrix(0.0, nrow = k_r, ncol = T_eff + 1L)
  Syy   <- numeric(T_eff + 1L)
  
  for (i in 1:T_eff) {
    zui <- Zu[i, ]
    zri <- Zr[i, ]
    yi  <- yresp[i]
    
    Sxx_u[, , i + 1L] <- Sxx_u[, , i] + tcrossprod(zui)
    Sxy_u[, i + 1L]   <- Sxy_u[, i] + zui * yi
    
    Sxx_r[, , i + 1L] <- Sxx_r[, , i] + tcrossprod(zri)
    Sxy_r[, i + 1L]   <- Sxy_r[, i] + zri * yi
    
    Syy[i + 1L] <- Syy[i] + yi * yi
  }
  
  list(
    p = p,
    include_const = include_const,
    T_eff = T_eff,
    k_u = k_u,
    k_r = k_r,
    Sxx_u = Sxx_u,
    Sxy_u = Sxy_u,
    Sxx_r = Sxx_r,
    Sxy_r = Sxy_r,
    Syy = Syy
  )
}

## Prepare prefix sums for all p = 1..pmax
.prep_prefix_allp <- function(y, x, pmax, include_const) {
  pmax <- as.integer(pmax)
  if (pmax < 1L) stop("pmax must be >= 1.")
  out <- vector("list", pmax)
  for (p in 1:pmax) {
    out[[p]] <- .prep_prefix_onep(y, x, p, include_const)
  }
  out
}

## Compute window F quickly from prefix object of a given p
## window start w, window length m
## mapping:
##   regression uses t = w+p ... w+m-1  (length m-p)
##   in the p-regression indexing (t = p+1..L), this corresponds to i = w .. w+m-p-1
.F_from_prefix_window <- function(pref, w, m) {
  p <- pref$p
  n_eff <- m - p
  if (n_eff <= 0L) return(NA_real_)
  
  ## df1 is number of restrictions = p (x-lag coefficients)
  df1 <- p
  df2 <- n_eff - pref$k_u
  if (df2 <= 0L) return(NA_real_)
  
  i1 <- w
  i2 <- w + m - p - 1L
  if (i1 < 1L || i2 > pref$T_eff || i2 < i1) return(NA_real_)
  
  ## sums over i = i1..i2
  XTX_u <- pref$Sxx_u[, , i2 + 1L] - pref$Sxx_u[, , i1]
  XTy_u <- pref$Sxy_u[, i2 + 1L]   - pref$Sxy_u[, i1]
  
  XTX_r <- pref$Sxx_r[, , i2 + 1L] - pref$Sxx_r[, , i1]
  XTy_r <- pref$Sxy_r[, i2 + 1L]   - pref$Sxy_r[, i1]
  
  yy <- pref$Syy[i2 + 1L] - pref$Syy[i1]
  
  ## solve for beta and compute RSS
  ## RSS = yy - XTy' * beta
  beta_u <- tryCatch(solve(XTX_u, XTy_u), error = function(e) NULL)
  beta_r <- tryCatch(solve(XTX_r, XTy_r), error = function(e) NULL)
  if (is.null(beta_u) || is.null(beta_r)) return(NA_real_)
  
  rss_u <- as.numeric(yy - crossprod(XTy_u, beta_u))
  rss_r <- as.numeric(yy - crossprod(XTy_r, beta_r))
  if (!is.finite(rss_u) || !is.finite(rss_r) || rss_u <= 0) return(NA_real_)
  
  Fval <- ((rss_r - rss_u) / df1) / (rss_u / df2)
  Fval
}

## Fast sup-F for rolling windows with window-specific p_vec
.fast_supF <- function(y, x, m, p_vec, include_const) {
  y <- as.numeric(y); x <- as.numeric(x)
  m <- as.integer(m)
  N <- length(y)
  nW <- N - m + 1L
  if (length(p_vec) != nW) stop("p_vec length must be nW = N-m+1.")
  
  pmax <- max(p_vec)
  pref_all <- .prep_prefix_allp(y, x, pmax, include_const)
  
  supF <- -Inf
  ## we only need the max, no need to store the whole sequence
  for (w in 1:nW) {
    p <- p_vec[w]
    Fw <- .F_from_prefix_window(pref_all[[p]], w, m)
    if (is.finite(Fw) && Fw > supF) supF <- Fw
  }
  supF
}


# In the residual bootstrap, the additional windows induced by the pseudo-sample length m+T-1 are 
# evaluated with a fixed lag order 1, by design, to keep the padding segment stable and 
# to avoid re-selecting lag orders for windows that are only used to align the rolling construction

# p_boot: full-sample bootstrap DGP lag

bootstrap_TS_fast <- function(y, x, m, B = 500, include_const = TRUE, lag_max_boot = 5L,
                              seed = NULL, p_vec = NULL, fit0 = NULL) {
  .assert_numeric_vec(y, "y")
  .assert_numeric_vec(x, "x")
  if (length(y) != length(x)) stop("y and x must have the same length.")
  if (!is.null(seed)) set.seed(seed)
  
  m <- as.integer(m)
  B <- as.integer(B)
  lag_max_boot <- as.integer(lag_max_boot)
  
  N <- length(y)
  if (N < m + 5) stop("Sample too short relative to window length m.")
  if (B < 1) stop("B must be >= 1.")
  if (lag_max_boot < 1) stop("lag_max_boot must be >= 1.")
  
  nW <- N - m + 1L ##number of windows
  
  # ---- choose p_boot on full sample using VARselect (BIC / SC(n)) ----
    type_var <- if (include_const) "const" else "none"

    sel <- vars::VARselect(
      y = cbind(y, x),
      lag.max = lag_max_boot,
      type = type_var
    )$selection

    # SC(n) is BIC in vars::VARselect output naming
    p_boot <- as.integer(sel[["SC(n)"]])

    # fallback in case of unexpected output
    if (!is.finite(p_boot) || p_boot < 1L) {p_boot <- 1L
  } else {
    p_boot <- as.integer(p_boot)
    if (!is.finite(p_boot) || p_boot < 1L) stop("p_boot must be a positive integer.")
  }


  # rolling lag vector (window-specific)
  if (is.null(p_vec)) {
    p_vec <- rep(p_boot, nW)  # fixed lag across windows
  } else {
    p_vec <- as.integer(p_vec)
    if (length(p_vec) != nW) stop("p_vec must have length nW = N - m + 1.")
    if (any(!is.finite(p_vec)) || any(p_vec < 1)) stop("p_vec must be positive integers.")
  }
  
  # feasibility checks for all windows
  if (m <= max(p_vec) + 6L) stop("m too small relative to max(p_vec). Increase m or reduce p_vec.")
  if (m <= p_boot + 6L) stop("m too small relative to p_boot. Increase m or reduce p_boot.")
  
  # Observed rolling sup-F (window-specific lags)
  supF_obs <- .fast_supF(y, x, m, p_vec, include_const)
  
  # Fit restricted model on full sample under H0 using p_boot
  if (is.null(fit0)) {
    fit0 <- var_ols_boot_restricted(y, x, lag_order = p_boot, include_const = include_const)
  }
  
  M = N+m-1  #bootstrap pseudo sample length
  nW_star <- M - m + 1L  # number of windows in bootstrap pseudo sample, which is N
  
  ## Extend p_vec (length nW) to p_vec_star (length nW_star)
  ## Extra windows: set lag = p_boot
  if (nW_star > nW) {
    p_vec_star <- c(p_vec, rep.int(p_boot, nW_star - nW))
  } else if (nW_star == nW) {
    p_vec_star <- p_vec
  } else {
    stop("Internal error: nW_star < nW, check M and m.")
  }
  
  supF_star <- numeric(B)
  for (b in 1:B) {
    sim <- DGP_boot(fit0, M)
    yb <- sim$y
    xb <- sim$x
    
    ## Fast bootstrap sup-F on length-M series:
    ## nW_star = M-m+1 windows, and p_vec_star has that same length
    supF_star[b] <- .fast_supF(yb, xb, m, p_vec_star, include_const)
  }
  
  p_value_boot <- mean(supF_star >= supF_obs)
  crit95 <- stats::quantile(supF_star, probs = 0.95, names = FALSE, type = 7)
  
  list( p_boot = p_boot,
        p_vec = p_vec,
        m = m,
        B = B,
        supF_obs = supF_obs,
        crit95 = crit95,
        p_value = p_value_boot)
}








# ============================================================
# Support functions for Empirical Illustration
# ============================================================
add_phe_shade <- function(phe_start, phe_end) {
  usr <- par("usr")
  rect(xleft = phe_start, xright = phe_end,
       ybottom = usr[3], ytop = usr[4],
       col = "grey90", border = NA)
}

run_bootstrap_lgrid_plot_time <- function(y, x, dates_w,
                                          l_grid = c(13, 26, 39, 52),
                                          B = 499,
                                          include_const = TRUE,
                                          lag_max_default = 5,
                                          seed = 123,
                                          phe_start = as.Date("2020-01-31"),
                                          phe_end   = as.Date("2023-05-11")) {
  
  y <- as.numeric(y); x <- as.numeric(x)
  if (length(y) != length(x)) stop("y and x must have the same length.")
  if (!inherits(dates_w, "Date")) stop("dates_w must be a Date vector.")
  if (length(dates_w) != length(y)) stop("dates_w must have the same length as y/x.")
  
  N <- length(y)
  directions <- c("x_to_y", "y_to_x")
  
  res <- vector("list", length(l_grid))
  names(res) <- paste0("m_", l_grid)
  
  for (ii in seq_along(l_grid)) {
    m <- as.integer(l_grid[ii])
    nW <- N - m + 1L
    if (nW < 1) stop("m too large.")
    
    # window end dates: t_end[w] corresponds to window w:(w+m-1)
    t_end <- dates_w[m:N]  # length nW
    
    # p_hat: compute once per direction, then reuse in both rolling and bootstrap
    p_hat <- select_lag_each_window(
      y = y, x = x, m = m,
      lag_max_default = lag_max_default,
      include_const = include_const)
    
    # observed rolling F sequences (no extra work beyond what you already do)
    roll_xy <- GC_OLS_roll(y = y, x = x, m = m, include_const = include_const,
                           direction = "x_to_y", p_hat = p_hat)
    F_seq_xy <- roll_xy$Fstat
    maxF_xy  <- max(F_seq_xy, na.rm = TRUE)
    
    roll_yx <- GC_OLS_roll(y = y, x = x, m = m, include_const = include_const,
                           direction = "y_to_x", p_hat = p_hat)
    F_seq_yx <- roll_yx$Fstat
    maxF_yx  <- max(F_seq_yx, na.rm = TRUE)
    
    # bootstrap: x_to_y uses (y,x); y_to_x uses swapped inputs (x,y)
    boot_xy <- bootstrap_TS_fast(y = y, x = x, m = m, B = B,
                                 include_const = include_const,
                                 seed = seed + 1000L + m,
                                 lag_max_boot = lag_max_default,
                                 p_vec  = p_hat)
    crit_xy <- boot_xy$crit95
    pval_xy <- boot_xy$p_value
    rm(boot_xy)
    
    boot_yx <- bootstrap_TS_fast(y = x, x = y, m = m, B = B,
                                 include_const = include_const,
                                 seed = seed + 2000L + m,
                                 lag_max_boot = lag_max_default,
                                 p_vec  = p_hat)
    crit_yx <- boot_yx$crit95
    pval_yx <- boot_yx$p_value
    rm(boot_yx)
    
    res[[ii]] <- list(
      m = m,
      t_end = t_end,
      x_to_y = list(F_seq = F_seq_xy, crit5 = crit_xy, p_boot = pval_xy, maxF = maxF_xy),
      y_to_x = list(F_seq = F_seq_yx, crit5 = crit_yx, p_boot = pval_yx, maxF = maxF_yx)
    )
  }
  
  # ---- tab with max(F) added ----
  tab <- do.call(rbind, lapply(l_grid, function(m) {
    key <- paste0("m_", m)
    c(
      m = m,
      p_boot_x_to_y = res[[key]]$x_to_y$p_boot,
      crit_x_to_y   = res[[key]]$x_to_y$crit5,
      maxF_x_to_y   = res[[key]]$x_to_y$maxF,
      p_boot_y_to_x = res[[key]]$y_to_x$p_boot,
      crit_y_to_x   = res[[key]]$y_to_x$crit5,
      maxF_y_to_x   = res[[key]]$y_to_x$maxF
    )
  }))
  tab <- as.data.frame(tab)
  
  # ---- plot 4*2 with time axis, PHE shade, and singleton markers ----
  oldpar <- par(no.readonly = TRUE)
  on.exit(par(oldpar))
  
  par(mfrow = c(length(l_grid), 2),
      mar = c(3.0, 3.6, 2.0, 1.0),
      oma = c(0.8, 0.8, 1.8, 0.4))
  
  for (m in l_grid) {
    key <- paste0("m_", m)
    t_end <- res[[key]]$t_end
    
    # left: x_to_y
    obj <- res[[key]]$x_to_y
    Fseq <- obj$F_seq
    crit <- obj$crit5
    sig_idx <- which(Fseq > crit)
    
    plot(t_end, Fseq, type = "l",
         xlab = "", ylab = "F-stat",
         main = paste0("x_to_y, m=", m,
                       ", boot p=", formatC(obj$p_boot, digits = 3, format = "f"),
                       ", maxF=", formatC(obj$maxF, digits = 3, format = "f")),
         ylim = range(c(Fseq, crit), finite = TRUE))
    add_phe_shade(phe_start, phe_end)
    lines(t_end, Fseq, type = "l")
    abline(h = crit, lty = 2)
    if (length(sig_idx) > 0) points(t_end[sig_idx], Fseq[sig_idx], pch = 16)
    
    axis.Date(1, at = pretty(t_end))
    
    # right: y_to_x
    obj <- res[[key]]$y_to_x
    Fseq <- obj$F_seq
    crit <- obj$crit5
    sig_idx <- which(Fseq > crit)
    
    plot(t_end, Fseq, type = "l",
         xlab = "", ylab = "F-stat",
         main = paste0("y_to_x, m=", m,
                       ", boot p=", formatC(obj$p_boot, digits = 3, format = "f"),
                       ", maxF=", formatC(obj$maxF, digits = 3, format = "f")),
         ylim = range(c(Fseq, crit), finite = TRUE))
    add_phe_shade(phe_start, phe_end)
    lines(t_end, Fseq, type = "l")
    abline(h = crit, lty = 2)
    if (length(sig_idx) > 0) points(t_end[sig_idx], Fseq[sig_idx], pch = 16)
    
    axis.Date(1, at = pretty(t_end))
  }
  
  mtext("Rolling F-stat (time axis) with bootstrap 5% critical value; points mark singleton rejections",
        outer = TRUE, cex = 1.05)
  
  list(tab = tab, res = res)
}



# ============================================================
# Rolling Plots in Figure 1

# ---------- adjusted p-value for each window ----------
p_tilde_from_pvals <- function(pvals) {
  Eu <- 0.5772157
  p <- as.numeric(pvals)
  p[p == 0] <- .Machine$double.xmin
  
  ok <- is.finite(p) & p > 0 & p <= 1
  K <- sum(ok)
  if (K <= 1) return(rep(NA_real_, length(p)))
  
  z <- rep(NA_real_, length(p))
  z[ok] <- 1 / (K * p[ok])
  
  par <- FMStable::setParam(
    alpha = 1,
    logscale = log(pi / 2),
    location = log(K) + 1 - Eu + log(pi / 2),
    pm = 0
  )
  
  out <- rep(NA_real_, length(p))
  out[ok] <- 1 - FMStable::pEstable(z[ok], par)
  out
}

plot_HMP_boot_2x2 <- function(X, week_vec, m, boot_res,
                              include_const = TRUE,
                              phe_start = as.Date("2020-01-31"),
                              phe_end   = as.Date("2023-05-11"),
                              alpha = 0.05,
                              ylim_hmp = c(0, 1)) {
  
  # --- checks ---
  if (!inherits(week_vec, "Date")) stop("week_vec must be Date.")
  if (!is.matrix(X) && !is.data.frame(X)) stop("X must be matrix/data.frame with 2 cols.")
  X <- as.matrix(X)
  if (ncol(X) < 2) stop("X must have at least 2 columns.")
  if (nrow(X) != length(week_vec)) stop("X and week_vec length mismatch.")
  name_y <- "returns"; name_x <- "IDEMV"
  
  key <- paste0("m_", as.integer(m))
  if (is.null(boot_res$res[[key]])) stop("boot_res$res does not contain: ", key)
  
  # --- precompute (same for both directions) ---
  type <- if (isTRUE(include_const)) "const" else "none"
  p_hat <- select_lag_each_window(X[, 1], X[, 2], m = m, include_const = include_const)
  
  # local drawers (do NOT touch par)
  draw_hmp <- function(direction) {
    roll <- GC_VAR(X, m = m, direction = direction, type = type, p_hat = p_hat)
    p_tilde <- p_tilde_from_pvals(roll$Pval)
    
    week_end <- week_vec[m:length(week_vec)]
    if (length(week_end) != length(p_tilde)) stop("Length mismatch in HMP panel.")
    
    ok <- is.finite(p_tilde)
    week_end <- week_end[ok]
    p_tilde  <- p_tilde[ok]
    
    if (direction == "x_to_y") {
      main_title <- bquote(HMP: .(name_x) %->% .(name_y))
    } else {
      main_title <- bquote(HMP: .(name_y) %->% .(name_x))
    }
    plot(week_end, p_tilde, type = "l",
         xlab = "", ylab = "",
         ylim = ylim_hmp,
         main = main_title)
    mtext(expression(tilde(p)), side = 2, line = 2.6)
    
    usr <- par("usr")
    x0 <- max(min(week_end), phe_start)
    x1 <- min(max(week_end), phe_end)
    if (x0 < x1) {
      rect(x0, usr[3], x1, usr[4],
           col = adjustcolor("grey70", alpha.f = 0.25), border = NA)
      lines(week_end, p_tilde)
    }
    
    abline(h = alpha, lty = 2)
    idx <- which(p_tilde <= alpha)
    if (length(idx) > 0) points(week_end[idx], p_tilde[idx], pch = 19)
    axis.Date(1, at = pretty(week_end))
  }
  
  draw_boot <- function(direction) {
    res_m <- boot_res$res[[key]]
    t_end <- res_m$t_end
    obj <- res_m[[direction]]
    
    Fseq <- obj$F_seq
    crit <- obj$crit5

    if (direction == "x_to_y") {
      main_title <- bquote(Bootstrap: .(name_x) %->% .(name_y))
    } else {
      main_title <- bquote(Bootstrap: .(name_y) %->% .(name_x))
    }
    plot(t_end, Fseq, type = "l",
         xlab = "", ylab = "F-stat",
         ylim = range(c(Fseq, crit), finite = TRUE),
         main = main_title)
    
    add_phe_shade(phe_start, phe_end)
    lines(t_end, Fseq)
    abline(h = crit, lty = 2)
    
    idx <- which(Fseq > crit)
    if (length(idx) > 0) points(t_end[idx], Fseq[idx], pch = 16)
    axis.Date(1, at = pretty(t_end))
  }
  
  # --- enforce one-page 2x2 layout ---
  oldpar <- par(no.readonly = TRUE)
  on.exit(par(oldpar), add = TRUE)
  
  layout(matrix(1:4, nrow = 2, byrow = TRUE))
  par(mar = c(3.2, 3.8, 2.2, 1.0), oma = c(0.8, 0.8, 2.0, 0.4))
  
  # Top row: HMP
  draw_hmp("x_to_y")
  draw_hmp("y_to_x")
  
  # Bottom row: Bootstrap
  draw_boot("x_to_y")
  draw_boot("y_to_x")
  
  mtext(paste0("Rolling Granger causality comparison (m = ", m, ")"),
        outer = TRUE, cex = 1.1)
}


