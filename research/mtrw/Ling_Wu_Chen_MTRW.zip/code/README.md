# Replication Package

This replication package contains all code needed to reproduce the empirical application figures/tables and the simulation results reported in the paper. 
The workflow is designed so that only `Run.R` performs file I/O and produces outputs. The other scripts contain supporting functions only.

---

## Contents

```
.
├── Run.R
├── Application.R
├── Simulation.R
├── README.md
├── All_Infectious_EMV_Data.csv
├── SP500_FRED.csv         # optional
├── output/                # created automatically after running Run.R
│   ├── tables/
│   └── figures/
└── adf_null_cache/        # created automatically after running Run.R (cache for simulations)
```

- **Run.R**: Main entry point. Reads/downloads data, prepares weekly series, runs application and simulations, and writes all outputs.
- **Application.R**: Supporting functions for the empirical application (rolling tests, bootstrap, plotting).
- **Simulation.R**: Supporting functions for simulation study (DGP, test procedures, ADF null cache utilities).
- **All_Infectious_EMV_Data.csv**: Required IDEMV input file (project root).
- **SP500_FRED.csv**: Optional cached S&P 500 input file (project root).
- **output/**: Automatically generated results (tables and figures).
- **adf_null_cache/**: Automatically generated cache used to accelerate the simulation (can be deleted and rebuilt).


---

## System Requirements

- R version: R 4.2+ recommended (newer versions are fine).
- Operating system: Windows/macOS/Linux supported.

---

## R Package Dependencies

The scripts require the following R packages:

- dplyr
- lubridate
- quantmod
- xts
- zoo
- vars
- FMStable
- ragg (recommended for stable high-quality PNG output)

Install missing packages with:

```r
install.packages(c(
  "dplyr","lubridate","quantmod","xts","zoo","vars","FMStable","ragg"
))
```

---

## Where to Run

`Run.R` is written to avoid relying on `setwd()`. It detects the project root from the script location when possible, so input CSV files should be placed in the same folder as `Run.R`.

---

## Data

### 1) IDEMV data (required)

Place the IDEMV CSV file in the project root:

```
All_Infectious_EMV_Data.csv
```

This file must contain:
- a date column that can be parsed by `as.Date(...)`
- a numeric IDEMV index column

If your column names differ from what `Run.R` expects, edit the corresponding column mapping section in `Run.R` (search for the IDEMV import block and adjust the column names).

### 2) S&P 500 data (downloaded automatically)

`Run.R` downloads the daily S&P 500 series from FRED (symbol `SP500`) via `quantmod::getSymbols(...)`, then constructs weekly returns.

To improve reproducibility and allow offline reruns, `Run.R` can cache the downloaded data as:

```
SP500_FRED.csv
```

If the cache exists, `Run.R` reads it instead of re-downloading.

---

## Outputs

After a successful run, outputs are written under:

- `output/tables/`: CSV tables produced by the simulations and application routines.
- `output/figures/`: figures produced by the empirical application.

A session log is also saved (if enabled in `Run.R`) to help diagnose environment differences:

- `output/sessionInfo.txt`

If you re-run the script, existing output files may be overwritten depending on the settings in `Run.R`.

---

## Cache Folder: `adf_null_cache/`

Some simulation components use a cached Monte Carlo approximation for the ADF(1) null distribution to speed up repeated runs.

- The cache directory is created automatically if it does not exist.
- You may delete `adf_null_cache/` at any time; it will be regenerated on the next run.
- Cache files are saved in .rds format; read with readRDS()

---

## Reproducibility Notes

- `Run.R` sets a fixed random seed for Monte Carlo and bootstrap procedures. Changing the seed, the number of bootstrap replications (`B`), or the number of Monte Carlo replications will change the numerical results.
- If you experience small numerical differences across machines, check:
  - R version
  - package versions
  - BLAS/LAPACK implementation
  - whether cached files were reused

Use `output/sessionInfo.txt` (if generated) to compare environments.

---

## Troubleshooting

### 1) IDEMV file not found

If you see an error like "cannot open file ... All_Infectious_EMV_Data.csv"", confirm:

- the file exists at `All_Infectious_EMV_Data.csv`
- the filename matches exactly (case-sensitive on some systems)

### 2) FRED download fails

If your environment blocks network access, ensure that `SP500_FRED.csv` is present so the script can run offline.

### 3) Figure export issues

If PDF export is unstable on your machine, the package uses PNG export (via `ragg::agg_png`) by default. PNG output is generally more robust across platforms. If you want PDF, switch to `grDevices::cairo_pdf(...)` in `Run.R`.

---

## Contact / Replication Support

If you encounter issues reproducing the results, please provide:

- the full error message
- your OS, R version, and package versions
- `output/sessionInfo.txt` (if available)
- the exact command you used to run the code
