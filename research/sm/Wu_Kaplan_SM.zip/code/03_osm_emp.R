####################################
###                              ###   
###    OSM Empirical Examples    ###
###                              ###
####################################
# Authors: Qian Wu & David M. Kaplan

# Example 1: general health vs. education
# Example 2: life satisfaction vs. education

# For saving results
OUTFILE <- "03_osm_emp_output.txt"

# Load files/packages
source("osm.R")
library(ggplot2)
library(ggmosaic)

# Settings for osm()
ALPHA <- 0.05 # FWER level
N <- 1e5      # Draws for computing critical value

# Load data created by 01_osm_emp_variable_selection22.R; raw UKHLS 2022 but only selected variables
df <- read.csv(file='selectuk.csv', fileEncoding='UTF-16LE')

# Age of the adult
age <- df$lmn_age_dv

# E is educational level, with categories {no HS, HS only, bachelor's, above bachelor's}, coded as 1-4
E <- df$lmn_nisced11_dv
# Note nobody in categories 0,1,4,5:  mean(E %in% c(0,1,4,5)) = 0
E[E==2] <- 21
E[E==3] <- 22
E[E==6] <- 23
E[E>=7 & E<=8] <- 24
E <- E - 20
edu.labels <- c("no-HS","HS","bachelor's","grad deg")

# H is general health, with categories from poor to excellent, (re)coded as 1-5
H <- 6 - df$lmn_scsf1
mean(df$lmn_nisced11_dv[age>=30 & age<=65]>0 & df$lmn_nisced11_dv[age>=30 & age<=65]<10 & H[age>=30 & age<=65]<6) # 0.9259603

# life satisfaction
LS<- df$lmn_sclfsato 
mean(df$lmn_nisced11_dv[age>=30 & age<=65]>0 & df$lmn_nisced11_dv[age>=30 & age<=65]<10 & df$lmn_sclfsato[age>=30 & age<=65]>0) # 0.9206801

# Generate LaTeX output from results
LaTeX.out.fn <- function(ret, levs, reverse) { # ret=returned by osm(); levs=text vector w/ CDF level names
  cv <- ret$cv
  maxstrlen <- max(nchar(levs))
  str <- sprintf("%%-%ds & %%s \\\\\n", maxstrlen)
  for (i in 1:length(levs)) {
    tmp <- ret$t.statistics[,i]
    comp <- tmp; if (reverse) comp <- -tmp
    cat(sprintf(str, levs[i],
                paste0(sprintf('%10s %10.6f',
                               ifelse(comp > cv,'\\innercell',ifelse(comp < -cv,'','\\outercell')),
                               tmp), collapse=' & ')))
  }
  cat("%\n")
  cat(sprintf("Gray shading: outer confidence set.
Bold: inner confidence set.
Confidence level $%d\\%%$.
Critical value computed using $N=\\numnornd{%d}$ random draws.\n", 
              round(100*(1-ALPHA)), N) )
}



### Example 1: general health & education

# Filter to obs w/ non-missing values and 30<=age<=65
keep.inds1 <- with(data=df, lmn_age_dv>=30     & lmn_age_dv<=65 & lmn_nisced11_dv>=2 & 
                            lmn_nisced11_dv<=8 & lmn_scsf1>=1   & lmn_scsf1<=5)
sink(file=OUTFILE, append=TRUE)
(ret <- osm(Y=H[keep.inds1], X=E[keep.inds1], alpha=ALPHA, N=N))
LaTeX.out.fn(ret=ret, levs=c('1: poor', '2: fair (or below)',
                             '3: good (or below) ', '4: very good (or below)'),
             reverse=TRUE)
sink()

# Plot subgroup proportion
pdf(file='osm_emp.pdf', width=4.8, height=4.3, pointsize=11)
Health <- factor (H[keep.inds1], level=1:5, labels= c("poor","fair","good","very good","excellent"))
Education <- factor (E[keep.inds1], level = 1:4, labels=edu.labels)
p2 <- ggplot() +
  geom_mosaic(aes(x=product(Health, Education), fill=Health),offset=0.015) +
  scale_fill_brewer(palette=2) + guides(fill="none") + 
  labs(y="General Health", fill="general health") + theme_mosaic()
# If want grayscale for printout friendly:
# p2 <- p2 +scale_fill_grey(start=0.8, end=0)
df2 <- ggplot_build(p2)$data[[1]]
df2$pr <- round(100*df2$.wt/sum(df2$.wt), 2)
df2$lab <- paste0(df2$.wt, "; ", df2$pr, "%")
p2 + geom_label(data=df2, size=2,
                aes(x=(xmin+xmax)/2, y=(ymin+ymax)/2, label=lab)) +
  theme(text=element_text(size=10), plot.margin=margin(t=-10, r=-10, b=0, l=1))
dev.off()


### Example 2: life satisfaction & education

# Filter to obs w/ non-missing values and 30<=age<=65
keep.inds2 <- with(data=df, lmn_age_dv>=30 & lmn_age_dv<=65 & lmn_nisced11_dv>=2 &
                            lmn_nisced11_dv<=8 & lmn_sclfsato>=1 & lmn_sclfsato<=7)
sink(file=OUTFILE, append=TRUE)
print(apply(table(LS[keep.inds2],E[keep.inds2]), MARGIN=2, FUN=function(col)col[7]/sum(col))) #P(Y=7|X=..)
(ret <- osm(Y=LS[keep.inds2], E[keep.inds2], alpha=ALPHA, N=N))
LaTeX.out.fn(ret=ret, levs=c('1: completely dsat.', '2: mostly dsat. (or below)', '3: somewhat dsat. (or below) ', '4: neither (or below)', '5: somewhat sat. (or below)', '6: mostly sat. (or below)'),
             reverse=TRUE)
sink()

# Plot subgroup proportion
pdf(file='osm_emp_app.pdf', width=4.8, height=4, pointsize=11)
Life <- factor (LS[keep.inds2], level=1:7, labels= c("completely dsat.","mostly dsat.","somewhat dsat.","neither","somewhat sat.", "mostly sat.", "completely sat."))
Education <- factor (E[keep.inds2], level = 1:4, labels=edu.labels)
p2 <- ggplot() +
  geom_mosaic(aes(x=product(Life, Education), fill=Life),offset=0.015) +
  scale_fill_brewer(palette=2) + guides(fill="none") + labs(y = "Satisfaction with Life Overall", fill = "life satisfaction") + theme_mosaic()
# If want grayscale for printout friendly:
# p2 <- p2 +scale_fill_grey(start=0.8, end=0)
df2 <- ggplot_build(p2)$data[[1]]
df2$pr <- round(100*df2$.wt/sum(df2$.wt), 2)
df2$lab <- paste0(df2$.wt, "; ", df2$pr, "%")
p2 + geom_label(data=df2, size=2,
                aes(x=(xmin+xmax)/2, y=(ymin+ymax)/2, label=lab)) +
  theme(text=element_text(size=10), plot.margin=margin(t=-10, r=-22, b=0, l=-16))
dev.off()

#EOF