# Code to create smaller data extract from raw data
# for "Multiple Testing of Stochastic Monotonicity"
# by Qian Wu and David M. Kaplan

# Install/load package to read .dta files into R
install.packages("haven") 
library(haven)

# Select variables from UKHLS 2022
df <- read_dta("lmn_indresp.dta")
varnames <- c('pidp','lmn_age_dv','lmn_nisced11_dv',
              'lmn_scsf1', 'lmn_sclfsato',
              'lmn_sf12pcs_dv', 'lmn_sf12mcs_dv')
write.csv(x=df[,varnames], file='selectuk.csv',
          fileEncoding='UTF-16LE', row.names=FALSE)
