Instructions for replicating empirical analysis for
"Ordinal Decomposition" by Qian Wu and David M. Kaplan

Files not mentioned below
  a. od.R: our code for counterfactual-based decomposition
  b. bod.R: our code for conventional Blinder-Oaxaca decomposition
  c. select22-codebook.pdf: the codebook (variable descriptions) for the NHIS 2022 data

Steps for replication

0. Before you start
 a. Make sure all files are in the same directory.
 b. Make sure the directory with all the files is the working directory in R; run getwd() if you're not sure, and change the working directory with setwd(...) if necessary.
 c. Note: all file input and output is from/to the working directory.

1.  Optional: to replicate from the raw NHIS data that you can download yourself, run 01_od_emp_variable_selection22.R after saving the raw NHIS 2022 Adult data as adult22.csv
 a. Goal: select (only) the needed variables from the raw data
 b. Input: adult22.csv (raw NHIS 2022 data downloaded from their website)
 c. Output: select22.csv (which is the data file we provide)

2.  Run 02_od_emp22.R
 a. Goal: main empirical decomposition analysis
 b. Input: select22.csv
 c. Output:
   i. od_emp22.csv: processed data
   ii. od_emp22.pdf: mosaic plot
   iii. 02_od_emp22_output.txt: decomposition results

3.  Run 03_series_logit.R
 a. Goal: model selection for nonparametric estimator (generate many candidate models and select the model with lowest AIC)
 b. Input: od_emp22.csv
 c. Output: 
   i. 03_series_logit_models.csv: X lists for each selected model
   ii. 03_series_logit_output.txt: regression results for each selected model
 
4.  Run 04_od_series_logit.R
 a. Goal: use the nonparametric estimator to construct the counterfactual ordinal distribution, and run decomposition analysis accordingly
 b. Inputs: od_emp22.csv and 03_series_logit_models.csv
 c. Output: 04_od_series_logit_output.txt (series logit decomposition results)

5.  Run 05_od_series_logit_cubic.R
 a. Goal: see if adding age^3 and/or income^3 improves AIC
 b. Input: variables already in memory (from running 04_od_series_logit.R)
 c. Output: shows AIC values in console
