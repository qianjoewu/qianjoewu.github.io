# Author: Qian Wu
# Goal: model selection for nonparametric logit for mental health application

# For saving results
OUTFILE1 <- "03_series_logit_output.txt"
OUTFILE2 <- "03_series_logit_models.csv"

# Load files/packages
library(fastglm)

# Load data created by 02_od_emp22.R
df <- read.csv(file='od_emp22.csv')
group_var <- c('group')
dep_var <- c('depression')
weights_var <- c('weights')

# Only need B subsample (group=1)
data.B <- df[df[,group_var]==1 , ]
J <- 4  #number of categories of Y

### Create variables for fastglm()
# Weights
data.B[,weights_var] <- data.B[,weights_var] / sum(data.B[,weights_var])
W.B <- data.B[,weights_var] * nrow(data.B)  # scales AIC more reasonably
# Binary outcomes, Y<=j
Yj.B <- t( apply(X=matrix(data.B[,dep_var],ncol=1), MARGIN=1,
                 FUN=function(y)as.integer(c(y<=1,y<=2,y<=3))) )
# Explanatory variables: X=always included, X2=candidate terms
X <- subset(data.B, select=c(high_edu, female, age, income, income_high,
                             northeast, midwest, west))
X$age_income <- X$age * X$income
X$age_income_high <- X$age * X$income_high
X$age_sq <- X$age^2
X$income_sq <- X$income^2
X2 <- with(data=X,
           data.frame(high_edu_female = high_edu * female,
                      high_edu_age = high_edu * age,
                      high_edu_income = high_edu * income,
                      high_edu_income_high = high_edu * income_high,
                      high_edu_northeast = high_edu * northeast,
                      high_edu_midwest = high_edu * midwest,
                      high_edu_west = high_edu * west,
                      female_age = female * age,
                      female_income = female * income,
                      female_income_high = female * income_high,
                      female_northeast = female * northeast,
                      female_midwest = female * midwest,
                      female_west = female * west,
                      age_northeast = age * northeast,
                      age_midwest = age * midwest,
                      age_west = age * west,
                      income_northeast = income * northeast,
                      income_midwest = income * midwest,
                      income_west = income * west,
                      income_high_northeast = income_high * northeast,
                      income_high_midwest = income_high * midwest,
                      income_high_west = income_high * west))
myX <- as.matrix(cbind(1, X, X2))  # includes intercept

########################################################################

(st <- Sys.time())  # check (and save) current clock time
MAX <- dim(X2)[2]  # number of candidate terms
trues <- rep(TRUE, 1+dim(X)[2])  # always-included terms

## Logit for Y<=y for y=1,2,3
# Initialize, then loop over all candidate models
best_AICs <- rep(Inf,3)
best_models <- vector(mode='list', length=3L)
for (i in 0:(2^MAX-1)) {
  xx <- myX[,c(trues,as.logical(intToBits(i))[1:MAX])]
  for (j in 1:3) {
    model <- fastglm(x=xx, y=Yj.B[,j], method=2,
                     family=binomial(link="logit"), weights=W.B)
    aic <- AIC(model)
    if (aic < best_AICs[j]) {
      best_AICs[j] <- aic
      best_models[[j]] <- model
    }
  }
}

# Check time and elapsed clock time
Sys.time()
Sys.time() - st

# Output elapsed time and models to file
sink(file=OUTFILE1, append=TRUE)
(Sys.time() - st)
for (j in 1:3) {
  print(summary(best_models[[j]]))
  cat(sprintf("AIC of best model (%d) = %g\n", j, best_AICs[j]))
}
sink()

# Output to file: for each j, best set of explanatory variables (excl. intercept)
# Format that can be read by next .R file
sink(file=OUTFILE2, append=FALSE)
for (j in 1:3) cat(paste0(names(best_models[[j]]$coefficients[-1]),collapse=','),sep='\n')
sink()
