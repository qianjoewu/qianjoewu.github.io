# Select variables from full NHIS 2022
df <- read.csv(file='adult22.csv', fileEncoding="UTF-8-BOM")
varnames <- c('HHX','WTFA_A','PHQCAT_A','URBRRL','EDUCP_A','SEX_A',
              'AGEP_A','POVRATTC_A','REGION')
write.csv(x=df[,varnames], file='select22.csv',
          fileEncoding='UTF-16LE', row.names=FALSE)
