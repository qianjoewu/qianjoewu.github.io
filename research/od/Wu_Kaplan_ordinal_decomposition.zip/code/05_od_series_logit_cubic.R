# Code to check if adding age^3 and/or income^3 improves AIC

# Assume still have df, x_var, dep_var, and weights_var in memory
#   from 04_od_series_logit.R

# Prep data/variables
J <- 4  #number of categories of Y
data.B <- df[df[,group_var]==1 , ]
data.B[,weights_var] <- data.B[,weights_var] / sum(data.B[,weights_var]) * nrow(data.B)

for (j in 1:3) {
  data.B$tmpYvar <- as.integer(data.B[,dep_var]<=j)
  logit0 <- glm(sprintf('tmpYvar~%s', paste0(x_var[[j]],collapse='+') ), data=data.B,
                family=binomial(link="logit"), weights=eval(parse(text=weights_var)) )
  logit1 <- glm(sprintf('tmpYvar~%s+age_cub', paste0(x_var[[j]],collapse='+') ), data=data.B,
                family=binomial(link="logit"), weights=eval(parse(text=weights_var)) )
  logit2 <- glm(sprintf('tmpYvar~%s+income_cub', paste0(x_var[[j]],collapse='+') ),
                data=data.B, family=binomial(link="logit"),
                weights=eval(parse(text=weights_var)) )
  logit3 <- glm(sprintf('tmpYvar~%s+age_cub+income_cub', paste0(x_var[[j]],collapse='+') ),
                data=data.B, family=binomial(link="logit"),
                weights=eval(parse(text=weights_var)) )
  print(c(AIC(logit0), AIC(logit1), AIC(logit2), AIC(logit3)))
}
# [1] 5256.865 5258.253 5258.702 5260.087
# [1] 2461.263 2462.697 2463.502 2464.941
# [1] 1192.270 1194.215 1194.315 1196.261