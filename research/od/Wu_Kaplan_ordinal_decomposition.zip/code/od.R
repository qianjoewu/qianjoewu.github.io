#######################################################################
###                                od                               ###   
###    od(dep_var, x_var, group_var, R, data, model, weights_var)   ###
###                                                                 ###
#######################################################################
# Author: Qian Wu

od <- function(dep_var, x_var, group_var, R=0, data, model, weights_var=NULL) {
  #dep_var is the name of dependent variable in the dataset
  #x_var is the vector of names of all x variables in the dataset,
  #   or a list with one such vector for each value of Y (excluding the highest)
  #group_var is the name of group dummy variable in the dataset
  #R indicates how many times for bootstrapping std. error
  #data is the data 
  #model indicates the model for estimation: model=1 for logit, model=2 for LPM/OLS
  #weights_var is the weight variable; if none, then ignore
  ###
  #example: 
  #data <- read.csv(file='data.csv')
  #x_var <- c('high_edu', 'female', 'age', 'age_sq', 'income','income_high','northeast', 'midwest', 'west')
  #od(dep_var='depression', x_var=x_var, group_var='group', R=1000,
  #   data=data, model=1, weights_var='weights')  
  
  # Treat R=NULL or R=NA same as R=0 (no standard errors / bootstrap)
  if (is.null(R) || is.na(R)) R <- 0

  # Validate 'model' argument
  if ( is.null(model) || missing(model) || is.na(model) ||
      !is.numeric(model) || !(model==1 || model==2) ) stop("Must set argument model=1 [logit] or model=2 [OLS/LPM]")
  
  # Check x_var for list vs. vector
  if (is.character(x_var)) {
    all_x <- x_var
  } else if (is.list(x_var)) {
    all_x <- unique(unlist(x_var))
  } else stop('x_var must be either vector or list')
  
  # Subset data to variables of interest and only complete cases
  data <- data[,c(dep_var,all_x,group_var,weights_var)]
  data <- data[complete.cases(data) , ]
  Yvals <- sort(unique(data[,dep_var]))
  J <- length(Yvals)
  
  # More x_var prep
  if (!is.list(x_var)) {
    x_var <- vector('list', J-1)
    for (j in 1:(J-1)) x_var[[j]] <- all_x
  } else if (length(x_var)!=(J-1)) stop('Length of x_var list must be J-1, where J is the number of unique values of Y')

  # subset data set based on group variable; 
  data.A <- data[data[,group_var]==0 , ]
  data.B <- data[data[,group_var]==1 , ]
  
  # Normalize weights to sum to 1 (separately by group A or B)
  if (!is.null(weights_var)) {
    data.A[,weights_var] <- data.A[,weights_var] / sum(data.A[,weights_var])
    data.B[,weights_var] <- data.B[,weights_var] / sum(data.B[,weights_var])
  }

  # Est'd CDFs and X means (include intercept/constant as first element)
  FhatA <- FhatB <- FhatC <- rep(NA, J-1)  #Fhat(v_J)=1, so only store J-1 values
  if (!is.null(weights_var)) {
    x.mean.A <- c(1, apply(X=data.A[,all_x], MARGIN=2, FUN=weighted.mean,
                           w=data.A[,weights_var]))
    x.mean.B <- c(1, apply(X=data.B[,all_x], MARGIN=2, FUN=weighted.mean,
                           w=data.B[,weights_var]))
    for (j in 1:(J-1)) {
      FhatA[j] <- weighted.mean(x=data.A[,dep_var]<=Yvals[j], w=data.A[,weights_var])
      FhatB[j] <- weighted.mean(x=data.B[,dep_var]<=Yvals[j], w=data.B[,weights_var])
    }
    y.mean.A <- weighted.mean(x=data.A[,dep_var], w=data.A[,weights_var])
    y.mean.B <- weighted.mean(x=data.B[,dep_var], w=data.B[,weights_var])
  } else {
    x.mean.A <- c(1, colMeans(data.A[,all_x]))
    x.mean.B <- c(1, colMeans(data.B[,all_x]))
    for (j in 1:(J-1)) {
      FhatA[j] <- mean(data.A[,dep_var]<=Yvals[j])
      FhatB[j] <- mean(data.B[,dep_var]<=Yvals[j])
    }
    y.mean.A <- mean(data.A[,dep_var])
    y.mean.B <- mean(data.B[,dep_var])
  }
  names(x.mean.A)[1] <- names(x.mean.B)[1] <- '(Intercept)'
  
  # X-related values
  out.X <- list(group.A=x.mean.A, group.B=x.mean.B,
                group.diff=x.mean.A-x.mean.B)

  # Sample sizes
  out.n <- c(group.A=nrow(data.A), group.B=nrow(data.B),
             total=nrow(data.A)+nrow(data.B))

  # Regressions
  out.Betas <- list()
  for (j in 1:(J-1)) {
    data.A$tmpYvar <- (data.A[,dep_var]<=Yvals[j])
    data.B$tmpYvar <- (data.B[,dep_var]<=Yvals[j])
    if (model==1) {
      if (!is.null(weights_var)) {
        # Note: glm() std errors wrong, but not used
        reg.object.A <- glm(sprintf('tmpYvar~%s', paste0(x_var[[j]],collapse='+') ),
                           data=data.A, family=quasibinomial(link="logit"),
                           weights=eval(parse(text=weights_var)) )
        reg.object.B <- glm(sprintf('tmpYvar~%s', paste0(x_var[[j]],collapse='+') ),
                           data=data.B, family=quasibinomial(link="logit"),
                           weights=eval(parse(text=weights_var)) )
        FhatC[j] <- weighted.mean(x=predict(reg.object.B, newdata=data.A, type="response"),
                                  w=data.A[,weights_var])
      } else {
        reg.object.A <- glm(sprintf('tmpYvar~%s', paste0(x_var[[j]],collapse='+') ),
                           data=data.A, family=binomial(link="logit") )
        reg.object.B <- glm(sprintf('tmpYvar~%s', paste0(x_var[[j]],collapse='+') ),
                           data=data.B, family=binomial(link="logit") )
        FhatC[j] <- mean(predict(reg.object.B, newdata=data.A, type="response"))
      }
    } else if (model==2) {
      if (!is.null(weights_var)) {
        reg.object.A <- lm(sprintf('tmpYvar~%s', paste0(x_var[[j]],collapse='+') ),
                           data=data.A, weights=eval(parse(text=weights_var)) )
        reg.object.B <- lm(sprintf('tmpYvar~%s', paste0(x_var[[j]],collapse='+') ),
                           data=data.B, weights=eval(parse(text=weights_var)) )
        FhatC[j] <- weighted.mean(x=predict(reg.object.B, newdata=data.A, type="response"),
                                  w=data.A[,weights_var])
      } else {
        reg.object.A <- lm(sprintf('tmpYvar~%s', paste0(x_var[[j]],collapse='+') ),
                           data=data.A )
        reg.object.B <- lm(sprintf('tmpYvar~%s', paste0(x_var[[j]],collapse='+') ),
                           data=data.B )
        FhatC[j] <- mean(predict(reg.object.B, newdata=data.A, type="response"))
      }
    } else stop('Need to set model=1 [logit] or model=2 [OLS/LPM]')
    beta.A <- coef(reg.object.A)
    beta.B <- coef(reg.object.B)
    out.Betas[[j]] <- rbind(beta.A=beta.A, beta.B=beta.B, beta.diff=beta.A-beta.B)
  }

  # "Mean" decomposition (equivalent to CDF/survival fn decomp *if* Yvals=1:J)
  y.mean.C <- sum(Yvals*(c(FhatC,1)-c(0,FhatC)))
  out.y <- list(y.mean.A=y.mean.A, y.mean.B=y.mean.B, y.mean.C=y.mean.C,
                share.explained=(y.mean.C-y.mean.B)/(y.mean.A-y.mean.B),
                share.unexplained=(y.mean.A-y.mean.C)/(y.mean.A-y.mean.B) )

  # CDF decomposition output (equivalent to survival function decomposition)
  out.distn <- list()
  out.distn$group.A <- FhatA
  out.distn$group.B <- FhatB
  out.distn$group.C <- FhatC
  
  # Aggregate decomposition
  Q.per <- sum(FhatC - FhatB) / sum(FhatA - FhatB)  # explained
  U.per <- sum(FhatA - FhatC) / sum(FhatA - FhatB)  # unexplained 
  
  out.twofold.aggregate <- rbind(c(Q.per, U.per))
  colnames(out.twofold.aggregate)  <- c("share(explained)","share(unexplained)")

  ######################################################################
  
  if (R>1) {  # Bootstrap SE if R>1
    # Save/set seed for replicability
    oldseed <- NULL
    if (exists(".Random.seed",.GlobalEnv)) { #.Random.seed #restore state at end
      oldseed <- get(".Random.seed",.GlobalEnv)
    }
    on.exit(if (!is.null(oldseed)) { assign(".Random.seed", oldseed, .GlobalEnv) }, add=TRUE)  
    set.seed(112358) # for replicability
    # Resample R times
    agg.res <- data.frame(Q.per.star=rep(NA,R), U.per.star=NA)
    n.A <- nrow(data.A);  n.B <- nrow(data.B)
    message("\nBootstrapping standard errors:")
    indicate.quantiles <- quantile(1:R, 0:10/10, type=1) # indicate progress
    for (r in 1:R) {
      if (r %in% indicate.quantiles) {
        message(sprintf('%d / %d (%2.0f%%)', r, R, round((r/R)*100,2)))
      }
      indA <- sample(x=1:n.A, size=n.A, replace=TRUE)
      indB <- sample(x=1:n.B, size=n.B, replace=TRUE)
      ret.star <- od(dep_var=dep_var, x_var=x_var, group_var=group_var,
                     R=0, data=rbind(data.A[indA,],data.B[indB,]),
                     model=model, weights_var=weights_var)
      agg.res[r,] <- ret.star$OD$`ordinal decomposition`
    }
    se <- matrix(apply(X=agg.res, MARGIN=2, FUN=sd), nrow=1)
    colnames(se) <- c("share.se(explained)","share.se(unexplained)")
  } else se <- matrix(NA,nrow=1,ncol=2)

  # Aggregate results
  order.twofold <- c("share(explained)","share.se(explained)",
                     "share(unexplained)","share.se(unexplained)")
  if (is.na(se[1])) order.twofold <- c("share(explained)","share(unexplained)")
  out.twofold.aggregate <- cbind(out.twofold.aggregate, se)[,order.twofold]
  out.twofold <- list(out.distn, out.twofold.aggregate)
  names(out.twofold) <- c("CDF values", "ordinal decomposition")
  out <- list(out.n, out.X, out.Betas, out.y, out.twofold)
  names(out) <- list("Sample size", "X mean", "Betas", 'Y "mean"', "OD")
  return(out)
}
