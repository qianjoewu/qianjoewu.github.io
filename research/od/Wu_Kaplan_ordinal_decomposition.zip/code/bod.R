##################################################################
###                             bod                            ###   
###    bod(dep_var, x_var, group_var, R, data, weights_var)    ###
###                                                            ###
##################################################################
# Author: Qian Wu

bod <- function(dep_var, x_var, group_var, R=0, data, weights_var=NULL) {
  #dep_var is the name of dependent variable in the dataset (data)
  #X_var is the vector of names of all x variables in the dataset
  #group_var is the name of group dummy variable in the dataset
  #R indicates how many times for bootstrapping std. error (0=no std errors)
  #data is the dataset (data.frame)
  #weights_var is the weight variable, or NULL (default) if no weights
  ###
  #example:
  #df <- read.csv(file='data.csv')
  #x_var <- c('high_edu', 'female', 'age', 'age_sq', 'income','income_high')
  #bod(dep_var='depression', x_var=x_var, group_var='group', R=1000,
  #    data=df, weights_var='weights')
  
  # Treat R=NULL or R=NA same as R=0 (no standard errors / bootstrap)
  if (is.null(R) || is.na(R)) R <- 0
  
  # Subset data to variables of interest and only complete cases
  data <- data[,c(dep_var,x_var,group_var,weights_var)]
  data <- data[complete.cases(data) , ]
  
  # subset data set based on group variable; 
  data.A <- data[data[,group_var]==0 , ]
  data.B <- data[data[,group_var]==1 , ]
  
  # Normalize weights to sum to 1 (separately by group A or B)
  if (!is.null(weights_var)) {
    data.A[,weights_var] <- data.A[,weights_var] / sum(data.A[,weights_var])
    data.B[,weights_var] <- data.B[,weights_var] / sum(data.B[,weights_var])
  }
  
  # Y and X sample means (include intercept/constant as first element)
  if (!is.null(weights_var)) {
    y.mean.A <- weighted.mean(x=data.A[,dep_var], w=data.A[,weights_var])
    y.mean.B <- weighted.mean(x=data.B[,dep_var], w=data.B[,weights_var])
    x.mean.A <- c(1, apply(X=data.A[,x_var], MARGIN=2, FUN=weighted.mean,
                           w=data.A[,weights_var]))
    x.mean.B <- c(1, apply(X=data.B[,x_var], MARGIN=2, FUN=weighted.mean,
                           w=data.B[,weights_var]))
  } else {
    y.mean.A <- mean(data.A[,dep_var])
    y.mean.B <- mean(data.B[,dep_var])
    x.mean.A <- c(1, colMeans(data.A[,x_var]))
    x.mean.B <- c(1, colMeans(data.B[,x_var]))
  }
  y.diff <- y.mean.A - y.mean.B
  names(x.mean.A)[1] <- names(x.mean.B)[1] <- '(Intercept)'
  
  # Y-related values
  out.y <- c(y.mean.A=y.mean.A, y.mean.B=y.mean.B, y.mean.diff=y.diff)
  
  # X-related values
  out.X <- list(group.A=x.mean.A, group.B=x.mean.B,
                group.diff=x.mean.A-x.mean.B)
  
  # Sample sizes
  out.n <- c(group.A=nrow(data.A), group.B=nrow(data.B),
             total=nrow(data.A)+nrow(data.B))
  
  # Regressions
  if (!is.null(weights_var)) {
    reg.object.A <- lm(paste0(dep_var,'~',paste0(x_var,collapse='+'),collapse=''),
                       data=data.A, weights=eval(parse(text=weights_var)) )
                       # data=data.A, weights=as.name(weights_var) )
    reg.object.B <- lm(paste0(dep_var,'~',paste0(x_var,collapse='+'),collapse=''),
                       data=data.B, weights=eval(parse(text=weights_var)) )
                       # data=data.B, weights=as.name(weights_var) )
  } else {
    reg.object.A <- lm(paste0(dep_var,'~',paste0(x_var,collapse='+'),collapse=''),
                       data=data.A)
    reg.object.B <- lm(paste0(dep_var,'~',paste0(x_var,collapse='+'),collapse=''),
                       data=data.B)
  }
  
  # Coefficient differences
  beta.A <- coef(reg.object.A)
  beta.B <- coef(reg.object.B)

  # Aggregate decomposition
  Q <- sum( (x.mean.A - x.mean.B) * beta.B) # explained
  Q.per <- Q / y.diff                       # explained share (proportion)
  U <- sum( x.mean.A * (beta.A-beta.B) )    # unexplained
  U.per <- U / y.diff                       # unexplained share (proportion)
  
  # Detailed decomposition
  Q.detailed <- (x.mean.A - x.mean.B) * beta.B
  Q.detailed.per <- Q.detailed / y.diff
  U.detailed <- x.mean.A * (beta.A-beta.B)
  U.detailed.per<- U.detailed / y.diff
  
  ### Coefficient (beta) differences
  out.Betas <- list(group.A=beta.A, group.B=beta.B,
                    group.diff=beta.A-beta.B)
  
  ### Regression objects
  out.reg <- list(reg.A=reg.object.A, reg.B=reg.object.B)
  # omit the call components
  out.reg$reg.A$call <- out.reg$reg.B$call <- NULL
  
  ### Two-fold output (coefficients)
  out.twofold.aggregate <- cbind(Q, Q.per, U, U.per)
  out.twofold.detailed <-
    cbind(Q.detailed, Q.detailed.per, U.detailed, U.detailed.per)
  colnames(out.twofold.aggregate) <- colnames(out.twofold.detailed) <-
    c("coef(explained)","share(explained)","coef(unexplained)","share(unexplained)")
  
  ######################################################################
  
  if (R>1) {  # Bootstrap SE if R>1
    # Save/set seed for replicability
    oldseed <- NULL
    if (exists(".Random.seed",.GlobalEnv)) { #.Random.seed #restore state at end
      oldseed <- get(".Random.seed",.GlobalEnv)
    }
    on.exit(if (!is.null(oldseed)) { assign(".Random.seed", oldseed, .GlobalEnv) }, add=TRUE)  
    set.seed(112358)
    # Resample R times
    agg.res <- array( data=NA, dim=c(length(c(out.twofold.aggregate)),R))
    det.res <- array( data=NA, dim=c(dim(out.twofold.detailed),R) )
    n.A <- nrow(data.A);  n.B <- nrow(data.B)
    message("\nBootstrapping standard errors:")
    indicate.quantiles <- quantile(1:R, 0:10/10, type=1) # indicate progress
    for (r in 1:R) {
      if (r %in% indicate.quantiles) {
        message(sprintf('%d / %d (%2.0f%%)', r, R, round((r/R)*100,2)))
      }
      indA <- sample(x=1:n.A, size=n.A, replace=TRUE)
      indB <- sample(x=1:n.B, size=n.B, replace=TRUE)
      ret.star <- bod(dep_var=dep_var, x_var=x_var, group_var=group_var,
                      R=0, data=rbind(data.A[indA,],data.B[indB,]),
                      weights_var=weights_var)
      agg.res[,r] <- ret.star$BOD$`aggregate decomposition`
      det.res[,,r] <- ret.star$BOD$`detailed decomposition`
    }
    se <- list(aggregate=rbind(apply(X=agg.res, MARGIN=1, FUN=sd)),
               detailed=apply(X=det.res, MARGIN=1:2, FUN=sd) )
    colnames(se$aggregate) <- colnames(se$detailed) <-
      c("se(explained)","share.se(explained)","se(unexplained)","share.se(unexplained)")
  } else se <- NULL
  
  ######################################################################
  
  order.twofold <-
    c("coef(explained)","se(explained)","share(explained)","share.se(explained)",
      "coef(unexplained)","se(unexplained)","share(unexplained)","share.se(unexplained)")
  if (is.null(se)) {
    order.twofold <- c("coef(explained)","share(explained)",
                       "coef(unexplained)","share(unexplained)")
    se <- list(aggregate=NA, detailed=NA)
  }
  
  out.twofold.aggregate <- cbind(out.twofold.aggregate, se$aggregate)[,order.twofold]
  out.twofold.detailed <- cbind(out.twofold.detailed, se$detailed)[,order.twofold]
  
  out.twofold <- list(out.y, out.twofold.aggregate, out.twofold.detailed)
  names(out.twofold) <- c("diff in y mean","aggregate decomposition","detailed decomposition")
  
  out <- list(out.n, out.X, out.Betas, out.twofold)
  names(out) <- list("Sample size", "X mean", "Betas", "BOD")
  return(out)  
}
