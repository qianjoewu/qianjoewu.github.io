####################################
###                              ###   
###     Empirical examples       ###
###                              ###
####################################
# Author: Qian Wu


# For saving results
OUTFILE <- "02_od_emp22_output.txt"

# Load files/packages
source("od.R")
source("bod.R")
library(ggplot2)
library(ggmosaic)

# Load data
# select22.csv is raw NHIS 2022 but only selected variables; see README
df <- read.csv(file='select22.csv', fileEncoding='UTF-16LE')

# Turn off scientific notation
options(scipen=999)       

########################################################################

# Filter by age and group (but also keep "NA" [AGEP_A>=90] for now; note URBRRL never NA)
df <- df[(df$AGEP_A>=24 & df$AGEP_A<=64) | df$AGEP_A>=90 , ]
df <- df[df$URBRRL==1 | df$URBRRL==4 , ]

### Generate usable variables from raw data

# Outcome variable: depression level, over {none/minimal, mild, moderate, severe}, coded 1-4
depression <- ifelse(df$PHQCAT_A<=4, df$PHQCAT_A, NA)

# Group dummy: 1 for urban (large central metro), 0 for rural (nonmetropolitan)
group <- ifelse(df$URBRRL==1, 1, ifelse(df$URBRRL==4, 0, NA))

# Explanatory variables -->

# high edu: some college and above (vs. HS only and below)
high_edu <- ifelse(df$EDUCP_A<=4, 0, ifelse(df$EDUCP_A<=10, 1, NA))

# female is a dummy variable, 1 indicates if female, 0 male, NA refused/don't know
female <- ifelse(df$SEX_A=='2', 1, ifelse(df$SEX_A=='1', 0, NA))

# age of the adult (and age squared)
age <- ifelse(df$AGEP_A<=90, df$AGEP_A, NA)
age_sq <- age^2

# income indicates income level 0-11 (SA family poverty ratio), top-coded
income <- df$POVRATTC_A
# income_high is a dummy for income>=11 (top-coded, per codebook)
income_high <- ifelse(income>=11, 1, 0)

# dummies for regions
northeast <- ifelse(df$REGION==1,1,0)
midwest <- ifelse(df$REGION==2,1,0)
south <- ifelse(df$REGION==3,1,0)
west <- ifelse(df$REGION==4,1,0)

# sampling weights
weights <- df$WTFA_A

# construct the new data frame
df <- data.frame(weights, depression, group, high_edu, female, age, age_sq,
                 income, income_high, northeast, midwest, west, south)
(n.orig <- nrow(df))  # before dropping obs w/ missing values
df <- na.omit(df)
(n.usable <- nrow(df))  # after dropping
c(dropped=n.orig-n.usable, dropped.percent=1-n.usable/n.orig)

# save for other .R files to use
write.csv(df, "od_emp22.csv", row.names=FALSE)

########################################################################

# Plot subgroup proportion
pdf(file='od_emp22.pdf', width=6.5, height=4.7, pointsize=11)
Depression <- factor(df$depression, level=1:4, 
                     labels=c("none/minimal","mild","moderate","severe"))
Group <-  factor(df$group, level=0:1, labels=c("rural","urban"))
p1 <- ggplot() +
  geom_mosaic(aes(weight=df$weights, x=product(Depression, Group), fill=Depression), offset=0.015) +
  scale_fill_brewer(palette=2) + guides(fill=guide_legend(reverse=TRUE)) + theme_mosaic()
# If want grayscale:
# p1 <- p1 + scale_fill_grey(start=0.8, end=0)
df1 <- ggplot_build(p1)$data[[1]]
df1$pr <- round(100*df1$.wt/sum(df1$.wt), 2)
df1$lab <- paste0(df1$pr, "%")
p1 + geom_label(data=df1, size=2,
                aes(x=(xmin+xmax)/2, y=(ymin+ymax)/2, label=lab)) +
  theme(text=element_text(size=10), plot.margin=margin(0,0,0,0)) +
  guides(fill=guide_legend(reverse=TRUE))
dev.off()

########################################################################

dep_var <- 'depression'
x_var <- c('high_edu', 'female', 'age', 'age_sq', 'income',
           'income_high', 'northeast', 'midwest', 'west')
group_var <- 'group'
weights_var <- 'weights'
R <- 1000

# Save numbers for tables in paper
Table.CDFs <- matrix(data=NA, nrow=4, ncol=3)
rownames(Table.CDFs) <-
  c('Rural', 'Urban', 'Counterfactual (OLS/LPM)', 'Counterfactual (logit)')
Table.decomp <- matrix(data=NA, nrow=3, ncol=4)
rownames(Table.decomp) <-
  c('Naive Blinder--Oaxaca', 'OLS/LPM', 'Logit')

# Start writing output to .txt file
sink(file=OUTFILE, append=TRUE)
cat('Detailed results followed by output for results in paper at bottom.\n\n')
# conventional BOD w/ 1,2,3,4 cardinalization w/ sampling weights
cat('### Detailed naive Blinder-Oaxaca results\n\n')
(ret <- bod(dep_var=dep_var, x_var=x_var, group_var=group_var, R=R,
            data=df, weights_var=weights_var))
Table.decomp['Naive Blinder--Oaxaca',] <-
  c(ret$BOD$`aggregate decomposition`['share(explained)'],
    ret$BOD$`aggregate decomposition`['share(unexplained)'],
    ret$BOD$`aggregate decomposition`['share.se(explained)'],
    ret$BOD$`aggregate decomposition`['share.se(unexplained)'] )
# OLS (model=2) w/ sampling weights
cat('### Detailed OLS/LPM results\n\n')
(ret <-  od(dep_var=dep_var, x_var=x_var, group_var=group_var, R=R,
            data=df, model=2, weights_var=weights_var))
Table.CDFs['Rural',] <- ret$OD$`CDF values`$group.A
Table.CDFs['Urban',] <- ret$OD$`CDF values`$group.B
Table.CDFs['Counterfactual (OLS/LPM)',] <- ret$OD$`CDF values`$group.C
Table.decomp['OLS/LPM',] <-
  c(ret$OD$`ordinal decomposition`['share(explained)'],
    ret$OD$`ordinal decomposition`['share(unexplained)'],
    ret$OD$`ordinal decomposition`['share.se(explained)'],
    ret$OD$`ordinal decomposition`['share.se(unexplained)'] )
# logit (model=1) w/ sampling weights
cat('### Detailed logit results\n\n')
(ret <-  od(dep_var=dep_var, x_var=x_var, group_var=group_var, R=R,
            data=df, model=1, weights_var=weights_var))
Table.CDFs['Counterfactual (logit)',] <- ret$OD$`CDF values`$group.C
Table.decomp['Logit',] <-
  c(ret$OD$`ordinal decomposition`['share(explained)'],
    ret$OD$`ordinal decomposition`['share(unexplained)'],
    ret$OD$`ordinal decomposition`['share.se(explained)'],
    ret$OD$`ordinal decomposition`['share.se(unexplained)'] )
# 
cat('### Output for tables in paper\n\n')
cat('%% Estimated CDF table\n')
cat('\\toprule\nGroup & {$\\hat{F}(1)$} & {$\\hat{F}(2)$} & {$\\hat{F}(3)$} \\\\\n\\midrule\n')
for (i in 1:nrow(Table.CDFs)) {
  cat(sprintf('%s\n%s\n\\\\[0pt]\n', rownames(Table.CDFs)[i],
              paste0(sprintf('& %9.7f ',Table.CDFs[i,]), collapse='') ) )
}
cat('\n')
cat('%% Decomposition table\n')
cat('\\toprule\nModel & {Explained (\\%)} & {Unexplained (\\%)} \\\\\n\\midrule\n')
for (i in 1:nrow(Table.decomp)) {
  tmp <- rownames(Table.decomp)[i]
  cat(sprintf('%-8s%s%s\\\\\n        %s\n\\\\[2pt]\n', 
              tmp, ifelse(nchar(tmp)<=8,'','\n        '),
              paste0(sprintf('&  %9.6f  ',100*Table.decomp[i,1:2]), collapse=''),
              paste0(sprintf('& (%9.6f) ',100*Table.decomp[i,3:4]), collapse='') ) )
}
sink()
