# Author: Qian Wu

source('od.R')  # load od() function

# For saving results
OUTFILE <- "04_od_series_logit_output.txt"

# Turn off scientific notation
options(scipen=999)       

# Load selected models for nonparametric logit
tmp <- read.csv(file='03_series_logit_models.csv', header=FALSE)
x_var1 <- stringi::stri_remove_empty(unlist(tmp[1,]))
x_var2 <- stringi::stri_remove_empty(unlist(tmp[2,]))
x_var3 <- stringi::stri_remove_empty(unlist(tmp[3,]))
x_var <- list(x_var1, x_var2, x_var3)

# Load data created by 02_od_emp22.R
df <- read.csv(file='od_emp22.csv')

# Construct additional explanatory terms like in 03_series_logit.R
addX <- with(data=df,
             data.frame(age_income = age * income,
                        age_income_high = age * income_high,
                        age_sq = age^2,
                        income_sq = income^2,
                        age_cub = age^3,
                        income_cub = income^3,
                        high_edu_female = high_edu * female,
                        high_edu_age = high_edu * age,
                        high_edu_income = high_edu * income,
                        high_edu_income_high = high_edu * income_high,
                        high_edu_northeast = high_edu * northeast,
                        high_edu_midwest = high_edu * midwest,
                        high_edu_west = high_edu * west,
                        female_age = female * age,
                        female_income = female * income,
                        female_income_high = female * income_high,
                        female_northeast = female * northeast,
                        female_midwest = female * midwest,
                        female_west = female * west,
                        age_northeast = age * northeast,
                        age_midwest = age * midwest,
                        age_west = age * west,
                        income_northeast = income * northeast,
                        income_midwest = income * midwest,
                        income_west = income * west,
                        income_high_northeast = income_high * northeast,
                        income_high_midwest = income_high * midwest,
                        income_high_west = income_high * west))
df <- data.frame(df, addX)

# Variable names
dep_var <- c('depression')
group_var <- c('group')
weights_var <- c('weights')
R <- 1000  # number of bootstrap replications

sink(file=OUTFILE, append=TRUE)
cat('### Detailed nonparametric logit results\n\n')
(ret <- od(dep_var=dep_var, x_var=x_var, group_var=group_var, R=R,
           data=df, model=1, weights_var=weights_var))
cat('### Output for tables in paper\n\n')
cat('%% Estimated CDF table\n')
cat(sprintf('%s\n%s\n\\\\\n', 'Counterfactual (series logit)',
            paste0(sprintf('& %9.7f ',ret$OD$`CDF values`$group.C), collapse='') ) )
cat('\n')
cat('%% Decomposition table\n')
tmp <- c(ret$OD$`ordinal decomposition`['share(explained)'],
         ret$OD$`ordinal decomposition`['share(unexplained)'],
         ret$OD$`ordinal decomposition`['share.se(explained)'],
         ret$OD$`ordinal decomposition`['share.se(unexplained)'] )
cat(sprintf('%-8s%s%s\\\\\n        %s\n\\\\\n', 
            'Series logit', ifelse(nchar('Series logit')<=8,'','\n        '),
            paste0(sprintf('&  %9.6f  ',100*tmp[1:2]), collapse=''),
            paste0(sprintf('& (%9.6f) ',100*tmp[3:4]), collapse='') ) )
sink()
